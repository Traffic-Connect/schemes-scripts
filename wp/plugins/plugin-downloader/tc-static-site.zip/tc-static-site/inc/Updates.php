<?php

namespace TC_Static_Site\inc;

/**
 * Индивидуальные действия при обновлении
 */
class Updates {
	private mixed $plugin_version;

	public function __construct() {
		$this->plugin_version = get_option( 'tc-static-site-version' );

		// Обновление до версии 1.14
		$this->update_114();
	}

	// Обновление до версии 1.14
	private function update_114() {
		if ( empty( $this->plugin_version ) || version_compare( $this->plugin_version, '1.14', '<' ) ) {
			$this->update_version();
			$this->update_config();
		}
	}

	// Обновление версии
	private function update_version() {
		$plugin_data = get_plugin_data( dirname( __DIR__ ) . '/tc-static-site.php' );
		update_option( 'tc-static-site-version', $plugin_data['Version'] );
	}

	// Обновление конфига
	private function update_config() {
		ServerConfig::build_config( get_option( 'tc-static-site-settings' ) );
	}
}
