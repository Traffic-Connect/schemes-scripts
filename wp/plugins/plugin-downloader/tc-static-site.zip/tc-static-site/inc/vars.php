<?php

define( 'TC_STATIC_SITE_DIR', 'static-site' );
define( 'TC_STATIC_SITE_DIR_CONFIG', $_SERVER['DOCUMENT_ROOT'] . '/wp-content/tc-static-site' );
