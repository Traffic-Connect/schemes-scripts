<?php

/**
 * Редиректы
 *
 * Добавить в static-load.php
 * $redirects = TC_STATIC_SITE_PATH . '/inc/integrarions/Redirects.php';
 * if ( file_exists( $redirects ) ) {
 * require $redirects;
 * \TC_Static_Site\inc\integrarions\Redirects::load();
 * }
 */

namespace TC_Static_Site\inc\integrarions;

class Redirects {
	/**
	 * Инициализация
	 */
	public function init() {
		add_action( 'admin_menu', [ $this, 'add_admin_submenu' ] );
		add_action( 'admin_post_update_redirects', [ $this, 'update_redirects' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'register_styles' ] );
	}

	/**
	 * Добавление подменю
	 */
	public function add_admin_submenu() {
		add_submenu_page( 'tc-static-site', 'Redirects', 'Redirects',
			'manage_options', 'tc-static-site-redirects', [ $this, 'render_admin_page' ] );
	}

	/**
	 * Рендер страницы редиректов
	 */
	public function render_admin_page() {
		$options = get_option( 'tc_static_site_redirects' );
		?>

		<div class="wrap page-redirects">
			<h2><?php echo get_admin_page_title() ?></h2>
			<?php do_action( 'tc-static-site-redirects-info' ); ?>
			<form method="post" action="<?php echo admin_url( 'admin-post.php' ); ?>">
				<input type="hidden" name="action" value="update_redirects">

				<div id="input-container">
					<?php if ( $options ): ?>
						<?php foreach ( $options as $option ): ?>
							<div class="row">
								<input type="text" name="from[]" value="<?php echo $option['from'] ?>">
								<input type="text" name="to[]" value="<?php echo $option['to'] ?>">
								<button class="remove">Удалить</button>
							</div>
						<?php endforeach; ?>
					<?php endif; ?>
					<div class="row">
						<input type="text" name="from[]"
							   placeholder="Относительный URL-адрес, с которого требуется перенаправить">
						<input type="text" name="to[]" placeholder="Целевой URL">
						<button class="remove">Удалить</button>
					</div>
				</div>

				<button id="add-row">Добавить ряд</button>

				<?php submit_button( 'Обновить редиректы' ); ?>
			</form>
		</div>

		<?php
	}

	/**
	 * Обновление редиректов
	 */
	public function update_redirects() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( __( 'У вас нет прав для выполнения этого действия' ) );
		}

		$field1 = (array) $_POST['from'];
		$field2 = (array) $_POST['to'];

		$redirects = [];
		for ( $i = 0; $i < count( $field1 ); $i ++ ) {
			if ( empty( $field1[ $i ] ) || empty( $field2[ $i ] ) ) {
				continue;
			}
			$redirects[] = [
				'from' => $field1[ $i ],
				'to'   => $field2[ $i ],
			];
		}

		update_option( 'tc_static_site_redirects', $redirects );
		$redirects = apply_filters( 'tc-static-site-redirects-update-config-before', $redirects );
		$this->update_redirect_config( $redirects );
		wp_redirect( admin_url( 'admin.php?page=tc-static-site-redirects' ) );
		exit;
	}

	/**
	 * Подключение стилей и скриптов
	 * @return void
	 */
	public function register_styles() {
		wp_enqueue_style( 'tc-static-site-redirects-style',
			plugins_url( 'assets/redirects.css', dirname( __FILE__, 2 ) ), [],
			filemtime( plugin_dir_path( dirname( __FILE__, 2 ) ) . 'assets/redirects.css' ) );
		wp_enqueue_script( 'tc-static-site-redirects-script',
			plugins_url( 'assets/redirects.js', dirname( __FILE__, 2 ) ),
			[ 'jquery' ], filemtime( plugin_dir_path( dirname( __FILE__, 2 ) ) . 'assets/redirects.js' ), false );
	}

	/**
	 * Обновление файла конфигурации редиректов
	 *
	 * @param  array  $redirects
	 *
	 * @return void
	 */
	public function update_redirect_config( array $redirects ) {
		$redirects_file = TC_STATIC_SITE_DIR_CONFIG . '/redirects.php';
		$data           = "<?php\n";
		$data           .= "return " . var_export( $redirects, true ) . ";\n";
		if ( ! file_put_contents( $redirects_file, $data ) ) {
			wp_die( __( 'Ошибка при создании файла конфигурации redirects.php' ) );
		}
	}

	/**
	 * Загрузка редиректов
	 */
	public static function load() {
		$redirects_file = TC_STATIC_SITE_DIR_CONFIG . '/redirects.php';
		if ( file_exists( $redirects_file ) ) {
			$data = (array) require $redirects_file;
			foreach ( $data as $item ) {
				$item['from'] = trim( $item['from'] );
				$item['to']   = trim( $item['to'] );
				$current_url  = ( ( ! empty( $_SERVER['HTTPS'] ) ) ? 'https' : 'http' ) . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
				if ( str_contains( $current_url, $item['from'] ) ) {
					header( 'Location: ' . $item['to'], true, 301 );
					exit;
				}
			}
		}
	}
}
