<?php

/**
 * Интеграция с плагином Redirection
 */

namespace TC_Static_Site\inc\integrarions;

class Redirects_Plugin {
	public function init() {
		// TODO Не отрабатывает
		add_action('init', function () {
			add_action( 'redirection_redirect_updated', [ $this, 'my_redirection_saved_handler' ] );
			add_action( 'tc-static-site-redirects-info', [ $this, 'redirection_info' ] );
		});
	}

	/**
	 * Вывод информации о текущих редиректах
	 * @return void
	 */
	public function redirection_info() {
		$items = $this->get_redirection_plugin();
		d( $items );
	}

	public function my_redirection_saved_handler() {
		$items = $this->get_redirection_plugin();
		//print_r($items);
		$ob = new Redirects();
		$ob->update_redirect_config( $items );
	}

	/**
	 * Проверка наличия таблицы редиректов плагина Redirection
	 * @return bool
	 */
	private function redirection_table_exists() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'redirection_items';

		$table_exists = $wpdb->get_var(
			$wpdb->prepare(
				"SHOW TABLES LIKE %s",
				$table_name
			)
		);

		return $table_exists === $table_name;
	}

	/**
	 * Получение редиректов плагина Redirection
	 * @return array
	 */
	private function get_redirection_plugin() {
		global $wpdb;

		if ( ! $this->redirection_table_exists() ) {
			return [];
		}

		// Автоматически подставит правильный префикс
		$table_name = $wpdb->prefix . 'redirection_items';

		// Получаем редиректы
		$redirects = $wpdb->get_results( "
        SELECT id, url, action_type, action_data
        FROM $table_name
        WHERE status = 'enabled'
        ORDER BY id DESC
    " );

		$result = [];

		foreach ( $redirects as $redirect ) {
			// Тип 1 — это обычный редирект
			if ( $redirect->action_type == 'url' ) {
				$result[] = [
					'from' => $redirect->url,
					'to'   => maybe_unserialize( $redirect->action_data ),
				];
			}
		}

		return $result;
	}
}
