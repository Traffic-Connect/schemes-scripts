<?php

/**
 * Определение главного зеркала
 */

namespace TC_Static_Site\inc\integrarions;

use TC_Static_Site\inc\ServerConfig;

class Mirror {
	public function init() {
		add_action( 'tc-static-site-build-config', [ $this, 'set' ] );
		if ( ! ServerConfig::getConfig( 'home_url' ) ) {
			$this->set();
		}
	}

	public function set() {
		$primary_host = trim( home_url(), '/' );
		ServerConfig::setConfig( 'home_url', $primary_host );
	}

	// Перенаправление
	public static function load() {
		$home_url = ServerConfig::getConfig( 'home_url' );
		if ( ! $home_url ) {
			return;
		}

		$primary_host   = parse_url( $home_url, PHP_URL_HOST );
		$primary_scheme = parse_url( $home_url, PHP_URL_SCHEME );

		$current_host = $_SERVER['HTTP_HOST'];

		if ( strtolower( $current_host ) !== strtolower( $primary_host ) ) {
			$redirect_url = $primary_scheme . '://' . $primary_host . $_SERVER['REQUEST_URI'];
			header( 'Location: ' . $redirect_url, true, 301 );
			exit;
		}
	}

}
