<?php

spl_autoload_register( function ( $class ) {
	if ( ! str_starts_with( $class, 'TC_Static_Site' ) ) {
		return;
	}
	$relative_class = str_replace( 'TC_Static_Site\\', '', $class );
	$file           = dirname( __DIR__ ) . '/' . str_replace( '\\', '/', $relative_class ) . '.php';
	if ( file_exists( $file ) ) {
		require_once $file;
	}
} );
