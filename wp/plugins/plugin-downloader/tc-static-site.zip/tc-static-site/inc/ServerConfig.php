<?php

namespace TC_Static_Site\inc;

class ServerConfig {

	public static function build_config( $option ) {
		self::remove_config();
		if ( ! empty( $option['enable'] ) ) {
			$output = array(
				'define( \'TC_STATIC_SITE\', \'static-site\', true );',
				'$request = trim( $_SERVER[\'REQUEST_URI\'], \'/\' );',
				'$request = str_replace( \'/\', \'|\', $request );',
				'if ( ! $request ) {',
				'	$request = \'/index\';',
				'}',
				'$static_file = __DIR__ . \'/wp-content/cache/static-site/\' . $request . \'.html\';',
				'if ( file_exists( $static_file ) ) {',
				'    $static_load = __DIR__ . "/wp-content/plugins/tc-static-site/static-load.php";',
				'    if ( file_exists( $static_load ) ) {',
				'       require $static_load;',
				'    }',
				'	readfile( $static_file );',
				'	exit;',
				'}',
			);
			self::updateMarkers( 'TC Static Site', $output, 'index.php', false, true );
			self::create_dir_config();
		}
		do_action( 'tc-static-site-build-config' );
	}

	/**
	 * Удаляем созданные конфиги
	 * @return void
	 */
	public static function remove_config() {
		self::updateMarkers( 'TC Static Site', [], 'index.php', true );
	}

	/**
	 * Write / update / delete marker to config file
	 *
	 * @param $marker
	 * @param  array  $insertion
	 * @param  string  $filename
	 * @param  bool  $delete
	 * @param  bool  $is_php
	 *
	 * @return bool
	 */
	public static function updateMarkers(
		$marker,
		array $insertion = [],
		string $filename = '.htaccess',
		bool $delete = false,
		$is_php = false
	): bool {
		$filename = ABSPATH . $filename;
		if ( ! file_exists( $filename ) ) {
			if ( ! is_writable( dirname( $filename ) ) ) {
				return false;
			}

			if ( ! touch( $filename ) ) {
				return false;
			}

			// Make sure the file is created with a minimum set of permissions.
			$perms = fileperms( $filename );

			if ( $perms ) {
				chmod( $filename, $perms | 0644 );
			}
		} elseif ( ! is_writable( $filename ) ) {
			return false;
		}

		if ( ! $delete ) {
			if ( ! is_array( $insertion ) ) {
				$insertion = explode( "\n", $insertion );
			}
		}

		$start_marker = "# BEGIN {$marker}";
		$end_marker   = "# END {$marker}";

		if ( $is_php ) {
			$config_content = file_get_contents( $filename );
			$php_content    = $start_marker . PHP_EOL . implode( PHP_EOL,
					$insertion ) . PHP_EOL . $end_marker . PHP_EOL;

			// Проверяем, существует ли уже эта запись
			if ( str_contains( $config_content, $php_content ) ) {
				return false;
			}

			$config_content = str_replace( '<?php', '', $config_content );
			$new_content    = "<?php\n\n$php_content" . $config_content;

			file_put_contents( $filename, $new_content );

			return true;
		}

		$fp = fopen( $filename, 'r+' );

		if ( ! $fp ) {
			return false;
		}

		// Attempt to get a lock. If the filesystem supports locking, this will block until the lock is acquired.
		flock( $fp, LOCK_EX );

		$lines = array();

		while ( ! feof( $fp ) ) {
			$lines[] = rtrim( fgets( $fp ), "\r\n" );
		}

		// Split out the existing file into the preceding lines, and those that appear after the marker.
		$pre_lines        = array();
		$post_lines       = array();
		$existing_lines   = array();
		$found_marker     = false;
		$found_end_marker = false;

		foreach ( $lines as $line ) {
			if ( ! $found_marker && str_contains( $line, $start_marker ) ) {
				$found_marker = true;
				continue;
			} elseif ( ! $found_end_marker && str_contains( $line, $end_marker ) ) {
				$found_end_marker = true;
				continue;
			}

			if ( ! $found_marker ) {
				$pre_lines[] = $line;
			} elseif ( $found_marker && $found_end_marker ) {
				$post_lines[] = $line;
			} else {
				$existing_lines[] = $line;
			}
		}

		// Check to see if there was a change.
		if ( ! $delete ) {
			if ( $existing_lines === $insertion ) {
				flock( $fp, LOCK_UN );
				fclose( $fp );

				return true;
			}
		}

		if ( ! $existing_lines && ! $delete ) {
			array_unshift( $pre_lines, "\n" );
		}

		// Generate the new file data.
		if ( $delete ) {
			foreach ( $post_lines as $k => $l ) {
				if ( $l == '' ) {
					unset( $post_lines[ $k ] );
				} else {
					break;
				}
			}
			$new_file_data = implode(
				"\n",
				array_merge(
					$pre_lines,
					$post_lines
				)
			);
		} else {
			$new_file_data = implode(
				"\n",
				array_merge(
					array( $start_marker ),
					$insertion,
					array( $end_marker ),
					$pre_lines,
					$post_lines
				)
			);
		}

		// Write to the start of the file, and truncate it to that length.
		fseek( $fp, 0 );
		$bytes = fwrite( $fp, $new_file_data );

		if ( $bytes ) {
			ftruncate( $fp, ftell( $fp ) );
		}

		fflush( $fp );
		flock( $fp, LOCK_UN );
		fclose( $fp );

		return (bool) $bytes;
	}

	/**
	 * Создание папки для конфигов
	 */
	public static function create_dir_config() {
		if ( ! is_dir( TC_STATIC_SITE_DIR_CONFIG ) ) {
			mkdir( TC_STATIC_SITE_DIR_CONFIG, 0755 );
		}
	}

	/**
	 * Запись в конфиг
	 * @param $key
	 * @param $value
	 * @param $delete
	 *
	 * @return void
	 */
	public static function setConfig( $key, $value, $delete = false ) {
		self::create_dir_config();
		$config_file = TC_STATIC_SITE_DIR_CONFIG . '/config.php';
		$data = array();
		if ( file_exists( $config_file ) ) {
			$data = require $config_file;
		}

		$data[ $key ] = $value;
		if ( $delete ) {
			unset( $data[ $key ] );
		}

		$config = "<?php\n";
		$config .= "return " . var_export( $data, true ) . ";\n";
		if ( ! file_put_contents( $config_file, $config ) ) {
			wp_die( __( 'Ошибка при создании файла config.php' ) );
		}
	}

	/**
	 * Получение значения конфига
	 * @param $key
	 *
	 * @return false|mixed
	 */
	public static function getConfig( $key ) {
		$config_file = TC_STATIC_SITE_DIR_CONFIG . '/config.php';
		$data        = [];
		if ( file_exists( $config_file ) ) {
			$data = (array) require $config_file;
		}
		if ( ! empty( $data[ $key ] ) ) {
			return $data[ $key ];
		} else {
			return false;
		}
	}
}
