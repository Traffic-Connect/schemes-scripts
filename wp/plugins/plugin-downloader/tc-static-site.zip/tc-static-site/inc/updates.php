<?php

/**
 * Индивидуальные действия при обновлении
 */

use TC_Static_Site\inc\ServerConfig;

// Обновление до версии 1.11
add_action('admin_init', function () {
	$plugin_version = get_option( 'tc-static-site-version' );
	if ( empty( $plugin_version ) || version_compare( $plugin_version, '1.11', '<' ) ) {
		$plugin_data = get_plugin_data( dirname( __DIR__ ) . '/tc-static-site.php' );
		update_option( 'tc-static-site-version', $plugin_data['Version'] );
		ServerConfig::build_config( get_option( 'tc-static-site-settings' ) );
	}
});
