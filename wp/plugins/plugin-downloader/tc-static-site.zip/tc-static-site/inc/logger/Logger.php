<?php

namespace TC_Static_Site\inc\logger;

class Logger
{
    private static ?Logger $instance = null;

    private string $logFile;

    private function __construct()
    {
        if (TC_STATIC_SITE_DIR_CONFIG) {
            $this->logFile = TC_STATIC_SITE_DIR_CONFIG . "/error.log";
        } else {
            $this->logFile = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/tc-static-site/error.log';
        }
    }

    public static function getInstance(): Logger
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function info(string $message, array $payload = []): void
    {
        $this->writeLog('INFO', $message, $payload);
    }

    public function warn(string $message, array $payload = []): void
    {
        $this->writeLog('WARN', $message, $payload);
    }

    public function error(string $message, array $payload = []): void
    {
        $this->writeLog('ERROR', $message, $payload);
    }

    private function writeLog(string $level, string $message, array $payload): void
    {
        $datetime = date('Y-m-d H:i:s');
        $entry = "[$datetime] [$level] $message " . json_encode($payload) . "\n";
        file_put_contents($this->logFile, $entry, FILE_APPEND);
    }
}
