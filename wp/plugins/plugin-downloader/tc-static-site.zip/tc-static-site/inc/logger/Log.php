<?php

namespace TC_Static_Site\inc\logger;

class Log
{
    public static function info(string $message, array $payload = []): void
    {
        Logger::getInstance()->info($message, $payload);
    }

    public static function warn(string $message, array $payload = []): void
    {
        Logger::getInstance()->warn($message, $payload);
    }

    public static function error(string $message, array $payload = []): void
    {
        Logger::getInstance()->error($message, $payload);
    }
}
