jQuery(document).ready(function ($) {
	let generate_buttons = $('.generate_buttons button');
	let generate_static_site = $('#generate_static_site');
	let generate_static_site_text = generate_static_site.text();
	let generate_static_site_sitemap = $('#generate_static_site_sitemap');
	let generate_static_site_sitemap_text = generate_static_site_sitemap.text();

	generate_static_site.on('click', function () {
		$.ajax({
			url: ajax_object.ajax_url,
			type: 'POST',
			dataType: 'json',
			cache: false,
			data: {
				action: 'generate_static_site'
			},
			beforeSend: function () {
				generate_static_site.text('Генерация...').addClass('loading');
				generate_buttons.prop('disabled', true);
			},
			success: function (response) {
				if (response.data.status === 'ok') {
					generate_static_site.text('Reloading...');
					location.reload();
					return;
				} else {
					console.log(response);
					if (response.data.message) {
						alert(response.data.message);
					} else {
						alert('Error message not found in response');
					}
				}

				generate_static_site.text(generate_static_site_text);
				generate_buttons.prop('disabled', false).removeClass('loading');
			},
			error: function (xhr, status, error) {
				console.error('Error AJAX:', error);
				generate_static_site.text(generate_static_site_text);
				generate_buttons.prop('disabled', false).removeClass('loading');
			}
		});
	});

	generate_static_site_sitemap.on('click', function () {
		$.ajax({
			url: ajax_object.ajax_url,
			type: 'POST',
			dataType: 'json',
			cache: false,
			data: {
				action: 'generate_static_site_sitemap'
			},
			beforeSend: function () {
				generate_static_site_sitemap.text('Генерация...').addClass('loading');
				generate_buttons.prop('disabled', true);
			},
			success: function (response) {
				if (response.data.status === 'ok') {
					generate_static_site_sitemap.text('Reloading...');
					location.reload();
					return;
				} else {
					console.log(response);
					if (response.data.message) {
						alert(response.data.message);
					} else {
						alert('Error message not found in response');
					}
				}

				generate_static_site_sitemap.text(generate_static_site_sitemap_text);
				generate_buttons.prop('disabled', false).removeClass('loading');
			},
			error: function (xhr, status, error) {
				console.error('Error AJAX:', error);
				generate_static_site_sitemap.text(generate_static_site_sitemap_text);
				generate_buttons.prop('disabled', false).removeClass('loading');
			}
		});
	});
});
