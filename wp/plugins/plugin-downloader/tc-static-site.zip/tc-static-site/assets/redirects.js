jQuery(document).ready(function ($) {
	$('.page-redirects #add-row').on('click', function (e) {
		e.preventDefault();
		const newRow = `
          <div class="row">
            <input type="text" name="from[]" placeholder="Относительный URL-адрес, с которого требуется перенаправить">
            <input type="text" name="to[]" placeholder="Целевой URL">
            <button class="remove">Удалить</button>
          </div>`;
		$('.page-redirects #input-container').append(newRow);
	});

	$('.page-redirects #input-container').on('click', '.remove', function (e) {
		e.preventDefault();
		$(this).closest('.row').remove();
	});
});
