<?php

// error_reporting( E_ALL );
// ini_set( 'display_errors', 1 );

if (!defined('TC_STATIC_SITE')) {
    exit;
}

class TC_Static_Load
{
    public function __construct()
    {
        require_once __DIR__ . '/inc/autoload.php';
        require_once __DIR__ . '/inc/vars.php';
    }

    // Инициализация
    public function init()
    {
        $static_file = $this->check_static_files();
        if ($static_file !== false) {
            $this->tc_waf();
            $this->mirror();
            $this->load_satic_file($static_file);
        }
    }

    // Проверка доступности запрошенного статического файла
    private function check_static_files()
    {
        $this->check_redirects();

        $request = trim(strtok($_SERVER['REQUEST_URI'], '?'), '/');

        if ($this->check_robots_txt($request) || $this->check_sitemap($request)) {
            return false;
        }

        $request = str_replace('/', '|', $request);
        if (!$request) {
            $request = '/index';
        }
        $static_file = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/cache/static-site/' . $request . '.html';

        if (isset($_GET['tc_static']) && str_contains($_GET['tc_static'], 'true')) {
            return false;
        }

        if (file_exists($static_file)) {
            return $static_file;
        }

        if (str_contains($request, 'wp-json')) {
            return false;
        }

        $this->render_404_page();
    }

    // Проверка наличия статического robots.txt
    private function check_robots_txt(string $requestUrl): bool
    {
        if ($requestUrl === 'robots.txt') {
            $static_file = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/cache/static-site/robots.txt';
            if (file_exists($static_file)) {
                header('Content-Type: text/plain; charset=utf-8');
                http_response_code(200);
                readfile($static_file);
                exit;
            }
            return true;
        }
        return false;
    }

    // Проверка наличия статического sitemap.xml
    private function check_sitemap(string $requestUrl): bool
    {
        if (str_contains($requestUrl, '.xml')) {
            $sitemap_dir = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/cache/static-site/sitemap/';
            $requested_file = $sitemap_dir . $requestUrl;

            // Проверяем наличие запрошенного файла
            if (file_exists($requested_file)) {
                header('Content-Type: application/xml; charset=utf-8');
                http_response_code(200);
                readfile($requested_file);
                exit;
            }

            // Специальная логика для sitemap.xml
            if ($requestUrl === 'sitemap.xml') {
                $sitemap_index_file = $sitemap_dir . 'sitemap_index.xml';
                if (file_exists($sitemap_index_file)) {
                    // Формируем URL с учетом протокола и хоста
                    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? 'https://' : 'http://';
                    $base_url = $protocol . $_SERVER['HTTP_HOST'];
                    header('Location: ' . $base_url . '/sitemap_index.xml', true, 301);
                    exit;
                }
                $this->render_404_page();
            } else {
                $this->render_404_page();
            }
        }
        return false;
    }

    // Проверка наличия статических редиректов
    private function check_redirects(): void
    {
        $redirectsFile = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/cache/static-site/redirects.php';

        if (!file_exists($redirectsFile)) {
            return;
        }

        $redirects = include $redirectsFile;
        if (!is_array($redirects)) {
            return;
        }

        $requestUri = strtok($_SERVER['REQUEST_URI'], '?');

        foreach ($redirects as $redirect) {
            if (!isset($redirect['from'], $redirect['to'], $redirect['status'])) {
                continue;
            }

            if (rtrim($redirect['from'], '/') === rtrim($requestUri, '/')) {
                header('Location: ' . $redirect['to'], true, $redirect['status']);
                exit;
            }
        }
    }


    // Подключаем TC WAF
    private function tc_waf()
    {
        $waf = $_SERVER['DOCUMENT_ROOT'] . "/wp-content/tc-waf-static/static.php";
        if (file_exists($waf)) {
            require $waf;
            $ob = new TC_Waf_Static;
            $ob->init();
        }
    }

    // Mirror
    private function mirror()
    {
        $mirror = __DIR__ . '/inc/integrarions/Mirror.php';
        if (file_exists($mirror)) {
            require $mirror;
            \TC_Static_Site\inc\integrarions\Mirror::load();
            \TC_Static_Site\inc\integrarions\Mirror::redirect_to_trailing_slash();
        }
    }

    // Загрузка статического файла
    private function load_satic_file($static_file)
    {
        readfile($static_file);
        exit;
    }

    private function render_404_page(): void
    {
        $not_found_file = $_SERVER['DOCUMENT_ROOT'] . '/wp-content/cache/static-site/404.html';

        http_response_code(404);

        if (file_exists($not_found_file)) {
            readfile($not_found_file);
        } else {
            echo '404 Not Found';
        }

        exit;
    }
}
