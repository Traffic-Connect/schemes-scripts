<?php

// error_reporting( E_ALL );
// ini_set( 'display_errors', 1 );

if ( ! defined( 'TC_STATIC_SITE' ) ) {
	exit;
}

define( 'TC_STATIC_SITE_PATH', $_SERVER['DOCUMENT_ROOT'] . '/wp-content/plugins/tc-static-site' );
require_once TC_STATIC_SITE_PATH . '/inc/autoload.php';
require_once TC_STATIC_SITE_PATH . '/inc/vars.php';

// Подключаем TC WAF
$waf = $_SERVER['DOCUMENT_ROOT'] . "/wp-content/tc-waf-static/static.php";
if ( file_exists( $waf ) ) {
	require $waf;
	$ob = new TC_Waf_Static;
	$ob->init();
}

// Mirror
$mirror = TC_STATIC_SITE_PATH . '/inc/integrarions/Mirror.php';
if ( file_exists( $mirror ) ) {
	require $mirror;
	\TC_Static_Site\inc\integrarions\Mirror::load();
}
