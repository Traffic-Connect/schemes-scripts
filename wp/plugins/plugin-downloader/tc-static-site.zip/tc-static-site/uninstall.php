<?php

/**
 * Выполняем действия при удалении плагина
 **/

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}

delete_option( 'tc-static-site-settings' );

// Удаляем созданные статические файлы
include_once __DIR__ . '/admin/Generate.php';
$ob = new \TC_Static_Site\admin\Generate();
$ob->delete_static_site( false );
