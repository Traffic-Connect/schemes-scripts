<?php
/**
 * Plugin Name: TC Static Site Generator
 * Description: Генерация статических HTML-файлов из контента WordPress.
 * Version: 1.12
 * Author: Sergey G.
 */

/**
 * План
 * Добавить относительные ссылки
 * Очищать кэш перед генерацией статических файлов
 */

// error_reporting( E_ALL );
// ini_set( 'display_errors', 1 );

use TC_Static_Site\admin\Admin;
use TC_Static_Site\admin\Generate;
use TC_Static_Site\admin\Integrations;
use TC_Static_Site\admin\Sitemap;
use TC_Static_Site\inc\ServerConfig;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/inc/autoload.php';
require_once __DIR__ . '/inc/vars.php';

class StaticSiteGenerator {
	public function __construct() {

		if ( is_admin() ) {
			new Admin();

			$generate = new Generate();
			$generate->init();

			new Sitemap();
			new Integrations();

			// Корректировки обновлений
			require_once __DIR__ . '/inc/updates.php';

			add_action( 'admin_notices', [ \TC_Static_Site\admin\Notices::class, 'admin_notice' ] );
		}
	}
}

// Действия при деактивации плагина
register_deactivation_hook( __FILE__, function () {
	ServerConfig::remove_config();
} );

new StaticSiteGenerator();
