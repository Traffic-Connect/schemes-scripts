<?php

namespace TC_Static_Site\admin;

class Sitemap {

	public function __construct() {
		add_action( 'wp_ajax_generate_static_site_sitemap', [ $this, 'sitemap' ] );
	}

	public function sitemap() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_success( [
				'message' => 'У вас нет прав для выполнения этого действия.',
				'status'  => 'error'
			] );
			die();
		}

		$generate = new Generate();


		// Удаляем старые HTML-файлы
		$generate->delete_static_site( false );

		// Получаем все из Sitemap
		$list = $this->get_sitemap();
		foreach ( $list as $url ) {
			if ( $url == get_home_url() . '/' ) {
				$filename = 'index';
			} else {
				//$filename = sanitize_file_name( basename( $url ) );
				$filename = parse_url( $url, PHP_URL_PATH );
				$filename = trim( $filename, '/' );
				$filename = str_replace( '/', '|', $filename );
			}

			$generate->generate_html_file( $url, $filename );
		}

		wp_send_json_success( [
			'status'  => 'ok',
			'count'   => count( $list )
		] );
		die();
	}

	private function get_sitemap() {
		$main_sitemap_url = get_home_url() . '/sitemap.xml';
		$main_sitemap     = simplexml_load_file( $main_sitemap_url );

		$all_pages = [];

		foreach ( $main_sitemap->sitemap as $sitemap ) {
			$sitemap_url = (string) $sitemap->loc;

			// Загружаем каждую под-карту
			$sub_sitemap = simplexml_load_file( $sitemap_url );

			foreach ( $sub_sitemap->url as $url ) {
				$clean_url   = preg_replace( '/[\?#].*/', '', $url->loc );
				$all_pages[] = (string) $clean_url;
			}
		}

		return array_unique( $all_pages );
	}
}
