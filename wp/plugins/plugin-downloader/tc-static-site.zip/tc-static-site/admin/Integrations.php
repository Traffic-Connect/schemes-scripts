<?php

namespace TC_Static_Site\admin;

use TC_Static_Site\inc\integrarions\Mirror;

class Integrations {
	public function __construct() {
		$ob = new Mirror();
		$ob->init();
	}
}
