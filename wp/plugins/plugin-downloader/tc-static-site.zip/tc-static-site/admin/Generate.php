<?php

namespace TC_Static_Site\admin;

class Generate {
	private int $home_id;
	private string $static_dir_path;

	public function __construct() {
		$this->static_dir_path = WP_CONTENT_DIR . '/cache/' . TC_STATIC_SITE_DIR;
		$this->home_id         = get_option( 'page_on_front', 0 );
	}

	public function init() {
		add_action( 'wp_ajax_generate_static_site', [ $this, 'generate_static_site' ] );
		add_action( 'admin_post_generate_file', [ $this, 'generate_file_handler' ] );
		add_action( 'admin_post_delete_static_site', [ $this, 'delete_static_site' ] );
		add_action( 'admin_post_delete_file', [ $this, 'delete_file_handler' ] );

		if ( isset( $_GET['status'] ) && $_GET['status'] === 'generated' ) {
			$errors = intval( $_GET['errors'] ?? 0 );
			if ( $errors > 0 ) {
				echo '<div class="notice notice-error"><p>Ошибки: ' . $errors . '</p></div>';
			}
		}
	}

	/**
	 * Генерация статических HTML-файлов
	 * @return void
	 */
	public function generate_static_site() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_success( [
				'message' => 'У вас нет прав для выполнения этого действия.',
				'status'  => 'error'
			] );
			die();
		}

		// Удаляем старые HTML-файлы
		$this->delete_static_site( false );

		// Получаем все опубликованные страницы и посты.
		$posts = get_posts( [
			'post_type'   => [ 'page' ],
			'post_status' => 'publish',
			'numberposts' => - 1,
		] );

		foreach ( $posts as $post ) {
			if ( $post->ID == $this->home_id ) {
				continue;
			}

			$url      = get_permalink( $post->ID );
			$filename = parse_url( $url, PHP_URL_PATH );
			$filename = trim( $filename, '/' );
			$filename = str_replace( '/', '|', $filename );
			//$filename = sanitize_file_name( $post->post_name );
			$this->generate_html_file( $url, $filename );
		}

		// Главная
		$this->generate_html_file( get_home_url(), 'index' );

		wp_send_json_success( [
			'status' => 'ok',
			'count'  => count( $posts )
		] );
		die();
	}

	/**
	 * Генерация HTML-файла для одной страницы/поста
	 *
	 * @param $url
	 * @param $filename
	 *
	 * @return bool
	 */
	public function generate_html_file( $url, $filename ) {
		if ( ! $url || ! $filename ) {
			return false;
		}

		// Загружаем контент с помощью wp_remote_get
		$content = wp_remote_get( $url, array(
			'headers' => array(
				'X-TCStaticHeader' => 1
			)
		) );

		if ( is_wp_error( $content ) || wp_remote_retrieve_response_code( $content ) !== 200 ) {
			Info::log( 'Ошибка при генерации HTML файла для URL ' . $url );

			return false;
		}

		// Получаем HTML-контент из тела ответа
		$html = wp_remote_retrieve_body( $content );
		if ( empty( $html ) ) {
			return false;
		}

		// Обрабатываем ассеты
		$assets_ob = new Assets();
		$assets_ob->process_assets( $html, $this->static_dir_path );
		$file_path = trailingslashit( $this->static_dir_path ) . $filename . '.html';

		// Проверяем и создаём директорию, если она не существует
		if ( ! is_dir( $this->static_dir_path ) ) {
			if ( ! mkdir( $this->static_dir_path, 0755, true ) ) {
				Info::log( 'Не удалось создать директорию: ' . $this->static_dir_path );

				return false;
			}
		}

		// Проверяем, доступна ли директория для записи
		if ( ! is_writable( $this->static_dir_path ) ) {
			Info::log( 'Директория недоступна для записи: ' . $this->static_dir_path );

			return false;
		}

		// Пишем контент в файл
		if ( file_put_contents( $file_path, $html ) === false ) {
			Info::log( 'Не удалось записать файл: ' . $file_path );

			return false;
		}

		return true;
	}

	/**
	 * Перегенерация отдельного HTML-файла
	 * @return void
	 */
	public function generate_file_handler() {
		// Проверяем параметры
		if ( empty( $_GET['file'] ) || empty( $_GET['_wpnonce'] ) ) {
			wp_die( 'Ошибка: отсутствуют параметры' );
		}

		$filename = sanitize_file_name( $_GET['file'] );
		$nonce    = $_GET['_wpnonce'];

		// Проверяем nonce
		if ( ! wp_verify_nonce( $nonce, 'generate_file_' . $filename ) ) {
			wp_die( 'Ошибка безопасности' );
		}

		$file_path = WP_CONTENT_DIR . '/cache/' . TC_STATIC_SITE_DIR . '/' . $filename;

		// Проверяем, существует ли файл
		if ( ! file_exists( $file_path ) ) {
			wp_die( 'Ошибка: файл не найден' );
		}

		if ( $filename == 'index.html' ) {
			$res = $this->generate_html_file( get_home_url(), 'index' );
		} else {
			$slug = preg_replace( '#\.html$#', '', $filename );
			$url  = get_home_url() . '/' . $slug;
			$res  = $this->generate_html_file( $url, $slug );
		}

		if ( $res ) {
			wp_redirect( $_SERVER['HTTP_REFERER'] );
			exit;
		} else {
			wp_die( 'Ошибка при генерации файла' );
		}
	}

	/**
	 * Удаление статических HTML-файлов
	 * @return void
	 */
	public function delete_static_site( $redirect ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_success( [
				'message' => 'У вас нет прав для выполнения этого действия.',
				'status'  => 'error'
			] );
			die();
		}

		if ( file_exists( $this->static_dir_path ) ) {
			$this->delete_directory( $this->static_dir_path );
		}

		if ( $redirect !== false ) {
			wp_redirect( admin_url( 'admin.php?page=tc-static-site&status=deleted' ) );
			exit;
		}
	}

	/**
	 * Удаление директории рекурсивно
	 *
	 * @param $dir
	 *
	 * @return void
	 */
	private function delete_directory( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}

		$files = array_diff( scandir( $dir ), [ '.', '..' ] );
		foreach ( $files as $file ) {
			$path = $dir . '/' . $file;
			if ( is_dir( $path ) ) {
				$this->delete_directory( $path );
			} else {
				unlink( $path );
			}
		}
		rmdir( $dir );
	}

	/**
	 * Удаление отдельного HTML-файла
	 * @return void
	 */
	public function delete_file_handler() {
		// Проверяем параметры
		if ( empty( $_GET['file'] ) || empty( $_GET['_wpnonce'] ) ) {
			wp_die( 'Ошибка: отсутствуют параметры' );
		}

		$filename = sanitize_file_name( $_GET['file'] );
		$nonce    = $_GET['_wpnonce'];

		// Проверяем nonce
		if ( ! wp_verify_nonce( $nonce, 'delete_file_' . $filename ) ) {
			wp_die( 'Ошибка безопасности' );
		}

		$file_path = WP_CONTENT_DIR . '/cache/' . TC_STATIC_SITE_DIR . '/' . $filename;

		// Проверяем, существует ли файл
		if ( ! file_exists( $file_path ) ) {
			wp_die( 'Ошибка: файл не найден' );
		}

		// Удаляем файл
		if ( unlink( $file_path ) ) {
			wp_redirect( $_SERVER['HTTP_REFERER'] );
			exit;
		} else {
			wp_die( 'Ошибка при удалении файла' );
		}
	}

}
