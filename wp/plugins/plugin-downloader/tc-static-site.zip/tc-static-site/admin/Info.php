<?php

namespace TC_Static_Site\admin;

class Info {
	public static function generated_num(): int {
		$directory = WP_CONTENT_DIR . '/cache/' . TC_STATIC_SITE_DIR;
		if ( ! file_exists( $directory ) ) {
			return 0;
		}
		$files     = scandir( $directory );
		$generated = 0;
		foreach ( $files as $file ) {
			if ( pathinfo( $file, PATHINFO_EXTENSION ) === 'html' ) {
				$generated ++;
			}
		}

		return $generated;
	}

	public static function file_list() {
		$files = glob( WP_CONTENT_DIR . '/cache/' . TC_STATIC_SITE_DIR . '/*.html' );
		if ( empty( $files ) ) {
			return null;
		}

		?>
		<table class="widefat striped fixed">
			<tbody>
			<?php foreach ( $files as $file ):
				$filename = basename( $file );
				$size = filesize( $file );
				$size_kb = round( $size / 1024, 2 );
				$file_date = date( "d.m.Y H:i:s", filemtime( $file ) );

				$nonce        = wp_create_nonce( 'delete_file_' . $filename );
				$delete_url   = admin_url( 'admin-post.php' ) . '?action=delete_file&file=' . urlencode( $filename ) . '&_wpnonce=' . $nonce;
				$nonce        = wp_create_nonce( 'generate_file_' . $filename );
				$generate_url = admin_url( 'admin-post.php' ) . '?action=generate_file&file=' . urlencode( $filename ) . '&_wpnonce=' . $nonce;

				$filename = str_replace( '|', '/', $filename );
				$url      = str_replace( '.html', '', $filename );
				if ( $filename === 'index.html' ) {
					$url = "";
				}
				?>
				<tr>
					<td>
						<a href="<?= $url ? "/$url" : "/" ?>" target="_blank"><?= $filename ?></a>
					</td>
					<td><?= $size_kb ?> КБ</td>
					<td><?= esc_html( $file_date ) ?></td>
					<td>
						<a href="<?= esc_url( $delete_url ) ?>" class="delete_file">
							Удалить
						</a>
					</td>
					<td>
						<a href="<?= esc_url( $generate_url ) ?>" class="generate_file">
							Перегенерить
						</a>
					</td>
				</tr>
			<?php endforeach ?>
			</tbody>
		</table>
		<?php
	}

	public static function instructions() {
		?>
		<div class="instructions">
			<h2 class="red">Важно понимать механизм работы</h2>
			<p>Плагин <b><u>генерирует статические HTML-файлы</u></b> на основе списка опубликованных страниц или
				sitemap данного сайта. <b><u>Он
						видит то же самое, что и обычный пользователь</u></b> при посещении сайта, и создает
				соответствующие HTML-файлы</p>
			<p>Посещение сайта пользователем осуществляется по сгенерированным HTML-файлам.
				<b class="red">Любые wordpress компоненты загружаться не будут</b>. Если какая-то страница не
				сгенерирована, она загружается
				стандартным методом из wordpress</p>
			<p><b><u>Если на сайте используется</u></b> плагины редиректа, динамический контент, функционал клоак и
				прочий функционал
				плагинов и тем, который например подстраивают контент под поведение пользователя, в таких случаях данное
				решение работать
				не будет, так как wordpress компоненты не загружаются.</p>
			<p>На данный момент для работы плагина адаптированы некоторые сторонние решения:</p>
			<ul>
				<li><b>TC WAF</b> — начиная с версии 1.23. Необходимо включить опцию "Включить поддержку плагина TC
					Static"
				</li>
				<li><b>Блок перелинковки</b> — все последние версии темы</li>
			</ul>
			<p>В блоки "Интеграции" ниже указаны текущие активные интеграции с плагинами и темами</p>
		</div>
		<?php
	}

	/**
	 * Добавление записи в лог
	 *
	 * @param $event
	 *
	 * @return void
	 */
	public static function log( $event ) {
		$filename = TC_STATIC_SITE_DIR_CONFIG . "/error.log";
		$str      = wp_date( "Y-m-d H:i:s" ) . "|" . $event;
		$handle   = fopen( $filename, "a" );
		fwrite( $handle, $str . "\n" );
		fclose( $handle );
	}

}
