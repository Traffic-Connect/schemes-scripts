<?php

namespace TC_Static_Site\admin;

class Notices {
	public static function get_notices() {
		$plugin_integrations = self::plugin_integrations();
		$theme_integrations  = self::theme_integrations();

		return array_merge( $plugin_integrations, $theme_integrations );
	}

	public static function output_notices( $notices = array() ) {
		$output = array();
		foreach ( $notices as $notice ) {
			if ( $notice['type'] == 'success' ) {
				$output[] = '<div class="notice-success">' . $notice['message'] . '</div>';
			} else {
				$output[] = '<div class="notice-error">' . $notice['message'] . '</div>';
			}
		}

		return implode( '', $output );
	}

	private static function plugin_integrations() {
		if ( ! is_plugin_active( 'hb_waf/hb-waf.php' ) ) {
			return array();
		}

		$notices     = array();
		$plugin_data = get_plugin_data( WP_PLUGIN_DIR . '/hb_waf/hb-waf.php' );

		// Проверяем версию
		if ( version_compare( $plugin_data['Version'], '1.23', '>=' ) ) {
			$hb_waf_settings = get_option( 'hb_waf_settings', [] );
			if ( empty( $hb_waf_settings['enable_static'] ) ) {
				$notices[] = array(
					'type'    => 'error',
					'message' => 'В плагине TC WAF отключена опция "Включить поддержку плагина TC Static'
				);
			} else {
				$notices[] = array( 'type' => 'success', 'message' => 'Интеграция с TC WAF' );
			}
		} else {
			$notices[] = array(
				'type'    => 'error',
				'message' => 'Плагин TC WAF активирован, но его версия ниже v1.23!'
			);
		}

		return $notices;
	}

	private static function theme_integrations() {
		$theme         = wp_get_theme();
		$theme_name    = $theme->parent() ? $theme->parent()->get( 'Name' ) : $theme->get( 'Name' );
		$theme_version = $theme->parent() ? $theme->parent()->get( 'Version' ) : $theme->get( 'Version' );
		$output        = array();

		// Satellite Theme
		if ( $theme_name == 'Satellite Theme' ) {
			// Linking Block
			if ( version_compare( $theme_version, '2.37', '>=' ) ) {
				$output[] = array( 'type' => 'success', 'message' => 'Интеграция с Linking Block' );
			} else {
				$output[] = array(
					'type'    => 'error',
					'message' => 'Версия темы Satellite не поддерживает интеграцию с Linking Block, обновите до версии 2.37'
				);
			}
		}

		// Salute Theme
		if ( $theme_name == 'Salute' ) {
			// Linking Block
			if ( version_compare( $theme_version, '1.14', '>=' ) ) {
				$output[] = array( 'type' => 'success', 'message' => 'Интеграция с Linking Block' );
			} else {
				$output[] = array(
					'type'    => 'error',
					'message' => 'Версия темы Salute не поддерживает интеграцию с Linking Block, обновите до версии 1.14'
				);
			}
		}

		return $output;
	}

	/**
	 * Вывод уведомления в админке об использовании плагина
	 */
	public static function admin_notice() {
		$screen  = get_current_screen();
		$options = get_option( 'tc-static-site-settings' );
		if ( ! empty( $screen ) && $screen->id !== 'toplevel_page_tc-static-site' &&
		     $screen->id !== 'tc-static-site_page_tc-static-site-redirects' && ! empty( $options['enable'] ) && Info::generated_num() > 0 ) {
			echo '<div class="notice notice-warning">
			<p><b><u>Внимание!!!</u></b> На сайте включен плагин генерации статических HTML-файлов <b>TC Static Site</b>, 
			после внесения любых изменений необходимо <a href="' . get_home_url() . '/wp-admin/admin.php?page=tc-static-site">
			перегенерировать</a> файлы сайта</p>
			</div>';
		}
	}
}
