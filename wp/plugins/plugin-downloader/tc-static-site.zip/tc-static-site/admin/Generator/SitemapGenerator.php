<?php

namespace TC_Static_Site\admin\Generator;

use TC_Static_Site\inc\logger\Log;

class SitemapGenerator
{
    private const FOLDER = 'static-site';

    public static function generate(): void
    {
        try {
            $active_seo_plugin = self::detectActiveSeoPlugin();
            Log::info('Обнаружен SEO-плагин', ['plugin' => $active_seo_plugin ?: 'none']);

            $sitemaps = self::fetchSitemaps($active_seo_plugin);

            if (empty($sitemaps)) {
                Log::warn('Sitemap пуст или не найден. Пропущено.');
                return;
            }

            $basePath = sprintf('%s/cache/%s/sitemap', WP_CONTENT_DIR, self::FOLDER);

            if (!is_dir($basePath)) {
                if (!mkdir($basePath, 0755, true) && !is_dir($basePath)) {
                    Log::error('Не удалось создать директорию для sitemap', ['path' => $basePath]);
                    return;
                }
            }

            foreach ($sitemaps as $sitemap) {
                $filePath = $basePath . '/' . $sitemap['filename'];
                file_put_contents($filePath, $sitemap['content']);

                Log::info('Sitemap загружен и сохранён', [
                    'url' => $sitemap['url'],
                    'filename' => $sitemap['filename'],
                    'path' => $filePath,
                ]);
            }
        } catch (\Throwable $e) {
            Log::error('Ошибка генерации sitemap: ' . $e->getMessage());
        }
    }

    private static function detectActiveSeoPlugin(): ?string
    {
        if (!function_exists('is_plugin_active')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        if (is_plugin_active('wordpress-seo/wp-seo.php') || is_plugin_active('wordpress-seo-premium/wp-seo-premium.php')) {
            return 'yoast';
        }

        if (is_plugin_active('all-in-one-seo-pack/all_in_one_seo_pack.php')) {
            return 'aioseo';
        }

        return null;
    }

    private static function fetchSitemaps(?string $active_seo_plugin): array
    {
        $result = [];

        if ($active_seo_plugin === 'yoast') {
            $indexUrl = site_url('/sitemap_index.xml');
            Log::info('Проверка sitemap для Yoast SEO', ['url' => $indexUrl]);
            $result = self::fetchSitemapFromUrl($indexUrl);
        } elseif ($active_seo_plugin === 'aioseo') {
            $indexUrl = site_url('/sitemap.xml');
            Log::info('Проверка sitemap для All in One SEO', ['url' => $indexUrl]);
            $result = self::fetchSitemapFromUrl($indexUrl);
        }

        if (empty($result)) {
            Log::info('SEO-плагин не определен или sitemap не найден, проверяем robots.txt');
            $result = self::fetchSitemapsFromRobotsTxt();
        }

        return $result;
    }

    private static function fetchSitemapFromUrl(string $indexUrl): array
    {
        $result = [];
        $response = wp_remote_get($indexUrl, ['timeout' => 30]);

        if (is_wp_error($response) || !is_array($response)) {
            Log::warn('Ошибка при скачивании sitemap', ['url' => $indexUrl, 'response' => $response]);
            return [];
        }

        $indexContent = wp_remote_retrieve_body($response);
        $filename = basename(parse_url($indexUrl, PHP_URL_PATH));

        $result[] = [
            'url' => $indexUrl,
            'filename' => $filename,
            'content' => $indexContent,
        ];

        // Пробуем разобрать как XML
        $xml = simplexml_load_string($indexContent, 'SimpleXMLElement', LIBXML_NOCDATA);
        if ($xml !== false && $xml->getName() === 'sitemapindex') {
            Log::info('Успешно разобран XML sitemap', ['url' => $indexUrl]);
            foreach ($xml->sitemap as $sitemap) {
                $childUrl = (string)$sitemap->loc;
                if (!empty($childUrl) && preg_match('#\.xml$#i', $childUrl)) { // Фильтр только .xml
                    $childResponse = wp_remote_get($childUrl, ['timeout' => 30]);
                    if (!is_wp_error($childResponse) && is_array($childResponse)) {
                        $childContent = wp_remote_retrieve_body($childResponse);
                        $result[] = [
                            'url' => $childUrl,
                            'filename' => basename(parse_url($childUrl, PHP_URL_PATH)),
                            'content' => $childContent,
                        ];
                        $nestedResult = self::fetchSitemapFromUrl($childUrl);
                        $result = array_merge($result, $nestedResult);
                    } else {
                        Log::warn('Ошибка при скачивании вложенного sitemap', ['url' => $childUrl]);
                    }
                }
            }
        } else {
            // Если XML не удалось разобрать, пробуем регулярные выражения (на случай HTML или поврежденного XML)
            Log::warn('Не удалось разобрать XML sitemap, переключаемся на регулярные выражения', ['url' => $indexUrl]);
            preg_match_all('#<loc>(https?://[^<]+)</loc>#i', $indexContent, $childMatches);
            foreach ($childMatches[1] ?? [] as $childUrl) {
                if (!empty($childUrl) && preg_match('#\.xml$#i', $childUrl)) { // Фильтр только .xml
                    $childResponse = wp_remote_get($childUrl, ['timeout' => 30]);
                    if (!is_wp_error($childResponse) && is_array($childResponse)) {
                        $childContent = wp_remote_retrieve_body($childResponse);
                        $result[] = [
                            'url' => $childUrl,
                            'filename' => basename(parse_url($childUrl, PHP_URL_PATH)),
                            'content' => $childContent,
                        ];
                        $nestedResult = self::fetchSitemapFromUrl($childUrl);
                        $result = array_merge($result, $nestedResult);
                    } else {
                        Log::warn('Ошибка при скачивании вложенного sitemap с регулярным выражением', ['url' => $childUrl]);
                    }
                }
            }
        }

        return $result;
    }

    private static function fetchSitemapsFromRobotsTxt(): array
    {
        $robotsTxtUrl = site_url('/robots.txt');
        Log::info('Скачиваем robots.txt', ['url' => $robotsTxtUrl]);

        $response = wp_remote_get($robotsTxtUrl, ['timeout' => 30]);
        if (is_wp_error($response) || !is_array($response)) {
            Log::warn('Не удалось получить robots.txt', ['response' => $response]);
            return [];
        }

        $lines = preg_split('/\r\n|\r|\n/', str_replace('\/', '/', wp_remote_retrieve_body($response)));
        Log::info('robots.txt строки', ['lines' => $lines]);

        foreach ($lines as $line) {
            if (!preg_match('/^\s*Sitemap:\s*(https?:\/\/\S+)/i', $line, $matches)) {
                continue;
            }

            return self::fetchSitemapFromUrl($matches[1]);
        }

        Log::warn('Sitemap не найден ни в одной строке robots.txt', ['lines' => $lines]);
        return [];
    }
}
