<?php

namespace TC_Static_Site\admin\Generator;

use TC_Static_Site\inc\logger\Log;

class RobotsTxtGenerator
{
    private const FOLDER = 'static-site';

    public static function generate(): void
    {
        try {
            $robotsContent = self::getRobotsContent();

            if (empty($robotsContent)) {
                Log::warn('Контент robots.txt пустой или не задан. Файл не сгенерирован.');
                return;
            }

            $robotsTxtPath = sprintf('%s/cache/%s/robots.txt', WP_CONTENT_DIR, self::FOLDER);
            file_put_contents($robotsTxtPath, $robotsContent);
        } catch (\Throwable $e) {
            Log::error('Ошибка генерации robots.txt: ' . $e->getMessage());
        }
    }

    private static function getRobotsContent(): string
    {
        $localFile = ABSPATH . 'robots.txt';

        if (file_exists($localFile)) {
            return file_get_contents($localFile) ?: '';
        }

        $response = wp_remote_get(site_url('/robots.txt'), ['timeout' => 30]);
        if (is_wp_error($response) || !is_array($response)) {
            return '';
        }

        return wp_remote_retrieve_body($response);
    }
}
