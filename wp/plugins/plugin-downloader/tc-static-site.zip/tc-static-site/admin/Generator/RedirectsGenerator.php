<?php

namespace TC_Static_Site\admin\Generator;

use TC_Static_Site\inc\logger\Log;
use wpdb;

class RedirectsGenerator
{
    private const FOLDER = 'static-site';
    private const REDIRECTS_FILE = 'redirects.php';

    public static function generate(): void
    {
        global $wpdb;

        try {
            $redirects = self::get_redirects_from_plugin($wpdb);

            if (empty($redirects)) {
                Log::warn('Редиректы не найдены. Пропущено.');
                // Удаляем старый файл, если он существует
                $filePath = sprintf('%s/cache/%s/%s', WP_CONTENT_DIR, self::FOLDER, self::REDIRECTS_FILE);
                if (file_exists($filePath)) {
                    unlink($filePath);
                }
                return;
            }

            $staticDir = sprintf('%s/cache/%s', WP_CONTENT_DIR, self::FOLDER);
            if (!is_dir($staticDir)) {
                mkdir($staticDir, 0755, true);
            }

            $filePath = $staticDir . '/' . self::REDIRECTS_FILE;
            $phpContent = '<?php' . PHP_EOL . PHP_EOL . 'return ' . var_export($redirects, true) . ';';

            file_put_contents($filePath, $phpContent);

            Log::info('Файл редиректов сохранён', ['path' => $filePath]);
        } catch (\Throwable $e) {
            Log::error('Ошибка генерации redirects.php: ' . $e->getMessage());
        }
    }

    private static function get_redirects_from_plugin(wpdb $wpdb): array
    {
        $table = $wpdb->prefix . 'redirection_items';

        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
            Log::warn('Таблица плагина Redirection не найдена: ' . $table);
            return [];
        }

        $rows = $wpdb->get_results("SELECT url, action_type, action_code, action_data FROM $table WHERE status = 'enabled'", ARRAY_A);

        $redirects = [];

        foreach ($rows as $row) {
            if (($row['action_type'] ?? '') !== 'url') {
                continue;
            }

            $from = trim($row['url'] ?? '');
            $to = trim($row['action_data'] ?? '');
            if ($to && str_starts_with($to, '/') === false) {
                $to = '/' . ltrim($to, '/');
            }
            $status = (int)($row['action_code'] ?? 301);

            if ($from && $to) {
                $redirects[] = [
                    'from' => $from,
                    'to' => $to,
                    'status' => $status,
                ];
            }
        }

        return $redirects;
    }
}
