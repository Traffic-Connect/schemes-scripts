<?php

namespace TC_Static_Site\admin;

use TC_Static_Site\inc\ServerConfig;

class Admin {
	public function __construct() {
		add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );
		add_action( 'admin_init', [ $this, 'plugin_settings_common' ] );
		add_action( 'admin_bar_menu', [ $this, 'admin_bar_link' ], 9999999999 );
		add_action( 'added_option', [ $this, 'build_config' ] );
		add_action( 'updated_option', [ $this, 'build_config' ] );
		add_action( 'admin_post_update_config', [ $this, 'rebuild_config' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'register_styles' ] );
	}

	/**
	 * Добавление пункта меню в админке
	 * @return void
	 */
	public function add_admin_menu() {
		add_menu_page( 'TC Static Site', 'TC Static Site', 'manage_options',
			'tc-static-site', [ $this, 'render_admin_page' ], 'dashicons-hammer'
		);
	}

	/**
	 * Рендер страницы админки
	 * @return void
	 */
	public function render_admin_page() {
		$generated = Info::generated_num();
		if ( $generated > 0 ) {
			echo '<div class="notice notice-success"><p>Сгенерировано страниц: ' . $generated . '</p></div>';
		} else {
			echo '<div class="notice notice-error"><p>Страницы не сгенерированы</p></div>';
		}
		?>
		<div class="wrap">
			<h2><?php echo get_admin_page_title() ?></h2>
			<?php if ( $generated ): ?>
				<form action="options.php" method="POST">
					<?php
					settings_fields( 'tc-static-site-common_group' );
					do_settings_sections( 'tc-static-site-common_page' );
					submit_button();
					?>
				</form>
				<div class="update_config_form">
					<p>В случае возникновения ошибок, попробуйте обновить конфигурацию</p>
					<form method="post" action="<?php echo admin_url( 'admin-post.php' ); ?>">
						<input type="hidden" name="action" value="update_config">
						<?php submit_button( 'Обновить конфигурацию', 'secondary' ); ?>
					</form>
				</div>
			<?php endif ?>
			<p>Вы можете сгенерировать или удалить статические HTML-файлы.</p>
			<div class="generate_buttons">
				<button id="generate_static_site" class="button button-primary">
					Генерировать HTML
				</button>
				<button id="generate_static_site_sitemap" class="button button-primary">
					Генерировать HTML из Sitemap
				</button>
			</div>
			<?= Info::file_list() ?>
			<form method="post" action="<?php echo admin_url( 'admin-post.php' ); ?>">
				<input type="hidden" name="action" value="delete_static_site">
				<?php submit_button( 'Удалить статические файлы', 'delete' ); ?>
			</form>
			<?php Info::instructions() ?>
			<h3>Интеграции</h3>
			<div class="notices-container">
				<?php
				$notices = Notices::get_notices();
				echo Notices::output_notices( apply_filters( 'tc_static_site_integration_notices', $notices ) );
				do_action( 'tc_static_site_integration' );
				?>
			</div>
			<div class="ver">
				Version <?= get_option( 'tc-static-site-version' ) ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Регистрируем опции
	 * @return void
	 */
	public function plugin_settings_common() {
		register_setting( 'tc-static-site-common_group', 'tc-static-site-settings',
			array( $this, 'sanitize_callback' ) );
		add_settings_section( 'tc-static-site-settings_id', 'Settings', '',
			'tc-static-site-common_page', [
				'section_class' => 'tc-static-site-settings_id',
			] );

		add_settings_field( 'tc-static-site-enable', 'Включить', [ $this, 'build_field' ],
			'tc-static-site-common_page', 'tc-static-site-settings_id',
			[
				'type'         => 'checkbox',
				'option_array' => 'tc-static-site-settings',
				'option'       => 'enable',
			]
		);
	}

	/**
	 * Build Field Function
	 *
	 * @param $args
	 *
	 * @return void
	 */
	public function build_field( $args ) {
		$option_id    = $args['option'];
		$option_name  = $args['option_array'] . "[" . $args['option'] . "]";
		$option_array = get_option( $args['option_array'] );
		$default      = ! empty( $args['default'] ) && $option_array === false ? $args['default'] : null;
		$value        = isset( $option_array[ $args['option'] ] ) ? esc_attr( $option_array[ $args['option'] ] ) : $default;
		?>

		<?php if ( $args['type'] == 'checkbox' ): ?>
			<input id="<?= $option_id ?>" type="checkbox" name="<?= $option_name ?>" value="1"
				<?php checked( 1, $value ) ?> /> <?= $args['checkbox_label'] ?? null ?>
		<?php endif ?>

		<?php if ( $args['type'] == 'select' ): ?>
			<select name="<?= $option_name ?>" id="<?= $option_id ?>">
				<?php foreach ( $args['choices'] as $key => $item ): ?>
					<?php if ( $key == $value ): ?>
						<option value="<?= $key ?>" selected><?= $item ?></option>
					<?php else: ?>
						<option value="<?= $key ?>"><?= $item ?></option>
					<?php endif ?>
				<?php endforeach ?>
			</select>
		<?php endif ?>

		<?php if ( ! empty( $args['comment'] ) ): ?>
			<p class="description"><?= $args['comment'] ?></p>
		<?php endif ?>

		<?php
	}

	/**
	 * Очистка данных
	 *
	 * @param $options
	 *
	 * @return mixed
	 */
	public function sanitize_callback( $options ) {
		return $options;
	}

	/**
	 * Ссылка в админ баре
	 */
	public function admin_bar_link( $wp_admin_bar ) {
		$args = array(
			'id'    => 'tc-static-site',
			'title' => 'TC Static Site',
			'href'  => '/wp-admin/admin.php?page=tc-static-site',
		);
		$wp_admin_bar->add_node( $args );
	}

	/**
	 * Обновление конфига
	 */
	public function build_config( $option_name ) {
		if ( 'tc-static-site-settings' == $option_name ) {
			$option = $_POST['tc-static-site-settings'];
			ServerConfig::build_config( $option );
		}
	}

	/**
	 * Перегенерация конфига
	 */
	public function rebuild_config() {
		$option = get_option( 'tc-static-site-settings' );
		ServerConfig::build_config( $option );
		wp_redirect( admin_url( 'admin.php?page=tc-static-site' ) );
		exit;
	}

	/**
	 * Подключение стилей и скриптов
	 * @return void
	 */
	public function register_styles() {
		wp_enqueue_style( 'tc-static-site-style', plugins_url( 'assets/style.css', dirname( __FILE__ ) ), [],
			filemtime( plugin_dir_path( dirname( __FILE__ ) ) . 'assets/style.css' ) );

		wp_enqueue_script( 'tc-static-site-script', plugins_url( 'assets/script.js', dirname( __FILE__ ) ),
			[ 'jquery' ], filemtime( plugin_dir_path( dirname( __FILE__ ) ) . 'assets/script.js' ), false );

		// Передаём ajax_url в JS
		wp_localize_script( 'tc-static-site-script', 'ajax_object', [
			'ajax_url' => admin_url( 'admin-ajax.php' ),
		] );
	}
}
