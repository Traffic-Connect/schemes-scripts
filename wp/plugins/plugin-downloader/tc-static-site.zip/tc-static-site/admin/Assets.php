<?php

namespace TC_Static_Site\admin;

class Assets {
	public function process_assets( &$html, $static_dir ) {
		$assets_dir      = home_url() . '/wp-content/cache/' . TC_STATIC_SITE_DIR . '/assets';
		$assets_dir_path = trailingslashit( $static_dir ) . 'assets';
		if ( ! file_exists( $assets_dir_path ) ) {
			mkdir( $assets_dir_path, 0755, true );
		}

		preg_match_all( '/<link[^>]+href=["\'](.*?\/wp-content\/cache\/.*?\.css(?:\?ver=\d+)?)["\']/i', $html, $css_matches );
		preg_match_all( '/<script[^>]+src=["\'](.*?\/wp-content\/cache\/.*?\.js(?:\?ver=\d+)?)["\']/i', $html, $js_matches );

		// Обрабатываем CSS файлы
		foreach ( $css_matches[1] as $css_url ) {
			$file_name = basename( parse_url( $css_url, PHP_URL_PATH ) );
			if ( ! file_exists( $assets_dir_path . '/' . $file_name ) ) {
				$res = $this->download_asset( $css_url, $assets_dir_path, $file_name );
			} else {
				$res = true;
			}
			if ( $res ) {
				// Удаляем версию из URL
				$clean_url = strtok( $css_url, '?' );
				$html      = str_replace( $css_url, trailingslashit( $assets_dir ) . basename( $clean_url ), $html );
			}
		}

		// Обрабатываем JS файлы
		foreach ( $js_matches[1] as $js_url ) {
			$file_name = basename( parse_url( $js_url, PHP_URL_PATH ) );
			if ( ! file_exists( $assets_dir_path . '/' . $file_name ) && ! str_contains( $js_url,
					'cloudflare-static' ) ) {
				$res = $this->download_asset( $js_url, $assets_dir_path, $file_name );
			} else {
				$res = true;
			}
			if ( $res ) {
				// Удаляем версию из URL
				$clean_url = strtok( $js_url, '?' );
				$html      = str_replace( $js_url, trailingslashit( $assets_dir ) . basename( $clean_url ), $html );
			}
		}
	}

	private function download_asset( $url, $assets_dir_path, $file_name ) {
		// Получаем содержимое файла
		$response = wp_remote_get( $url, [ 'timeout' => 10 ] );

		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
			error_log( 'Ошибка при загрузке ассета: ' . $url );

			return false;
		}

		// Формируем полный путь к файлу
		$local_path = trailingslashit( $assets_dir_path ) . $file_name;

		// Сохраняем файл локально
		if ( file_put_contents( $local_path, wp_remote_retrieve_body( $response ) ) === false ) {
			error_log( 'Не удалось сохранить файл: ' . $local_path );

			return false;
		}

		return true;
	}

	private function minify_css( $css ) {
		// Remove comments
		$css = preg_replace( '!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css );
		// Remove spaces before and after selectors, braces, and colons
		$css = preg_replace( '/\s*([{}|:;,])\s+/', '$1', $css );
		// Remove remaining spaces and line breaks
		$css = str_replace( array( "\r\n", "\r", "\n", "\t", '  ', '    ', '    ' ), '', $css );

		return $css;
	}

	private function minify_js( $js ) {
		// Удаляем однострочные комментарии
		$js = preg_replace( '/\/\/.*?\n/', "\n", $js );
		// Удаляем многострочные комментарии
		$js = preg_replace( '/\/\*.*?\*\//s', '', $js );
		// Удаляем лишние пробелы, табуляции, переносы строк
		$js = preg_replace( '/\s+/', ' ', $js );
		// Удаляем пробелы перед и после специальных символов
		$js = preg_replace( '/\s*([{};,:])\s*/', '$1', $js );
		// Удаляем пробелы в начале и конце строки
		$js = trim( $js );

		return $js;
	}

}
