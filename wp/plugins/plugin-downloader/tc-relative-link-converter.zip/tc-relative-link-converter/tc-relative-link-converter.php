<?php
/**
 * Plugin Name: TC Relative Link Converter
 * Description: Converts absolute links to relative on the frontend, with options to exclude canonical and hreflang links.
 * Version: 1.1
 * Author: Artem Khabarov
 */

class RelativeLinkConverter {

    /**
     * Initialize the plugin.
     */
    public function __construct() {
        add_action('admin_menu', [$this, 'add_settings_page']);
        add_action('admin_init', [$this, 'register_plugin_settings']);
        add_action('template_redirect', [$this, 'start_output_buffer']);
    }

    /**
     * Add plugin settings page to the admin menu.
     *
     * @return void
     */
    public function add_settings_page() {
        add_options_page(
            'Relative Link Converter',
            'Relative Link Converter',
            'manage_options',
            'relative-link-converter',
            [$this, 'render_settings_page']
        );
    }

    /**
     * Render the plugin settings page.
     *
     * @return void
     */
    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>Relative Link Converter Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('relative_link_converter_options_group');
                do_settings_sections('relative-link-converter');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    /**
     * Register plugin settings and fields.
     *
     * @return void
     */
    public function register_plugin_settings() {
        register_setting('relative_link_converter_options_group', 'relative_link_converter_options');

        add_settings_section(
            'relative_link_converter_main_section',
            'Main Settings',
            null,
            'relative-link-converter'
        );

        add_settings_field(
            'enable_relative_links',
            'Enable Relative Links',
            [$this, 'render_checkbox_field'],
            'relative-link-converter',
            'relative_link_converter_main_section',
            ['label_for' => 'enable_relative_links']
        );

        add_settings_field(
            'include_canonical',
            'Include Canonical Links',
            [$this, 'render_checkbox_field'],
            'relative-link-converter',
            'relative_link_converter_main_section',
            ['label_for' => 'include_canonical']
        );

        add_settings_field(
            'include_hreflang',
            'Include Hreflang Links',
            [$this, 'render_checkbox_field'],
            'relative-link-converter',
            'relative_link_converter_main_section',
            ['label_for' => 'include_hreflang']
        );
    }

    /**
     * Render a checkbox field.
     *
     * @param array $args Field arguments.
     * @return void
     */
    public function render_checkbox_field($args) {
        $options = get_option('relative_link_converter_options');
        $checked = isset($options[$args['label_for']]) ? 'checked' : '';
        echo '<input type="checkbox" id="' . esc_attr($args['label_for']) . '" name="relative_link_converter_options[' . esc_attr($args['label_for']) . ']" value="1" ' . $checked . ' />';
    }

    /**
     * Start output buffering.
     *
     * @return void
     */
    public function start_output_buffer() {
        if (!is_admin()) {
            $options = get_option('relative_link_converter_options');
            if (isset($options['enable_relative_links']) && $options['enable_relative_links']) {
                ob_start([$this, 'process_output_buffer']);
            }
        }
    }

    /**
     * Process the output buffer to convert links to relative.
     *
     * @param string $buffer The original content buffer.
     * @return string Processed content buffer.
     */
    public function process_output_buffer($buffer) {
        $options = get_option('relative_link_converter_options');
        $site_url = home_url();
        $parsed_url = parse_url($site_url);

        if (!isset($parsed_url['scheme'], $parsed_url['host'])) {
            return $buffer;
        }

        $base_url = $parsed_url['scheme'] . '://' . $parsed_url['host'];

        $excluded_content = [];

        $exclude_patterns = [];
        if (!isset($options['include_canonical']) || !$options['include_canonical']) {
            $exclude_patterns[] = '/<link[^>]*rel=["\']canonical["\'][^>]*>/i';
        }
        if (!isset($options['include_hreflang']) || !$options['include_hreflang']) {
            $exclude_patterns[] = '/<link[^>]*hreflang=["\'][^>]*>/i';
        }

        // Исключаем элементы и заменяем их на плейсхолдеры
        foreach ($exclude_patterns as $pattern) {
            preg_match_all($pattern, $buffer, $matches);
            if (!empty($matches[0])) {
                foreach ($matches[0] as $match) {
                    $placeholder = $this->escape_placeholder($match);
                    $excluded_content[$placeholder] = $match;
                    $buffer = str_replace($match, $placeholder, $buffer);
                }
            }
        }

        $buffer = str_replace($base_url, '', $buffer);
        $buffer = str_replace($parsed_url['host'], '', $buffer);

        foreach ($excluded_content as $placeholder => $original_content) {
            $buffer = str_replace($placeholder, $original_content, $buffer);
        }

        return $buffer;
    }


    /**
     * Escape content with a placeholder.
     *
     * @param string $content The original content.
     * @return string The escaped placeholder.
     */
    private function escape_placeholder($content) {
        return '###ESCAPED###' . md5($content) . '###';
    }
}

new RelativeLinkConverter();
