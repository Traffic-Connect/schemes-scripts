<?php

/*
Plugin Name: TC Lang Replace
Description: Делает принудительно замену lang и в og:locale
Version: 1.00
Author: Sergey G.
Network: true
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

use TC_Lang_Replace\admin\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'TC_Lang_Replace' ) ) :
	class TC_Lang_Replace {

		private mixed $option;

		public function __construct() {
			if ( is_admin() ) {
				require "admin/Admin.php";
				new Admin();
			} else {

				$this->option = get_option( 'tc-lang-replace-settings', [] );
				if ( ! empty( $this->option['lang'] ) ) {
					add_filter( 'language_attributes', [ $this, 'custom_change_lang_attribute' ] );
				}

				if ( ! empty( $this->option['wpseo_lang'] ) ) {
					add_filter( 'wpseo_locale', [ $this, 'custom_change_og_locale' ] );
				}
			}
		}

		public function custom_change_lang_attribute( $output ) {
			return 'lang="' . esc_attr( $this->option['lang'] ) . '"';
		}

		public function custom_change_og_locale( $locale ) {
			return $this->option['wpseo_lang'];
		}

	}

	new TC_Lang_Replace();
endif;
