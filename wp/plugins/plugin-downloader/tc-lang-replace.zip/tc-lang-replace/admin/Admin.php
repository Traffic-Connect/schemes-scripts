<?php

namespace TC_Lang_Replace\admin;

class Admin {

	public string $ip;
	public string $pref;

	public function __construct() {
		$this->pref = 'tc-lang-replace-';
		add_action( 'admin_menu', [ $this, 'menu' ], 20 );
		add_action( 'admin_init', [ $this, 'plugin_settings_common' ] );
	}

	/**
	 * Создаем пункт меню
	 * @return void
	 */
	public function menu() {
		add_options_page( 'TC Lang Replace', 'TC Lang Replace', 'manage_options',
			$this->pref . 'common_page', [ $this, 'display' ]
		);
	}

	function display() {
		?>
		<div class="wrap <?= $this->pref ?>container">
			<h2><?php echo get_admin_page_title() ?></h2>
			<form action="options.php" method="POST">
				<?php
				settings_fields( $this->pref . 'common_group' );
				do_settings_sections( $this->pref . 'common_page' );
				submit_button();
				?>
			</form>
		</div>
		<?php
	}

	/**
	 * Регистрируем опции
	 * @return void
	 */
	public function plugin_settings_common() {
		register_setting( $this->pref . 'common_group', $this->pref . 'settings',
			array( $this, 'sanitize_callback' ) );
		add_settings_section( $this->pref . 'settings_id', 'Settings', '',
			$this->pref . 'common_page', [
				'section_class' => $this->pref . 'settings_id',
			] );

		add_settings_field( $this->pref . 'lang', 'Lang', [ $this, 'build_field' ],
			$this->pref . 'common_page', $this->pref . 'settings_id',
			[
				'type'         => 'input',
				'option_array' => $this->pref . 'settings',
				'label_for'    => 'lang',
				'option'       => 'lang',
			]
		);
		add_settings_field( $this->pref . 'wpseo_lang', 'Yoast og:locale', [ $this, 'build_field' ],
			$this->pref . 'common_page', $this->pref . 'settings_id',
			[
				'type'         => 'input',
				'option_array' => $this->pref . 'settings',
				'label_for'    => 'wpseo_lang',
				'option'       => 'wpseo_lang',
			]
		);
	}

	/**
	 * Build Field Function
	 *
	 * @param $args
	 *
	 * @return void
	 */
	public function build_field( $args ) {
		$option_id    = $args['option'];
		$option_name  = $args['option_array'] . "[" . $args['option'] . "]";
		$option_array = get_option( $args['option_array'] );
		$default      = ! empty( $args['default'] ) && $option_array === false ? $args['default'] : null;
		$value        = isset( $option_array[ $args['option'] ] ) ? esc_attr( $option_array[ $args['option'] ] ) : $default;
		?>

		<?php if ( $args['type'] == 'checkbox' ): ?>
			<input id="<?= $option_id ?>" type="checkbox" name="<?= $option_name ?>" value="1"
				<?php checked( 1, $value ) ?> /> <?= $args['checkbox_label'] ?? null ?>
		<?php endif ?>

		<?php if ( $args['type'] == 'textarea' ): ?>
			<textarea id="<?= $option_id ?>" name="<?= $option_name ?>"
					  rows="<?= $args['rows'] ?>"><?= $value ?></textarea>
		<?php endif ?>

		<?php if ( $args['type'] == 'input' ): ?>
			<input id="<?= $option_id ?>" type="text" name="<?= $option_name ?>" value="<?= $value ?>" style="min-width: 300px"/>
		<?php endif ?>

		<?php if ( $args['type'] == 'select' ): ?>
			<select name="<?= $option_name ?>" id="<?= $option_id ?>">
				<?php foreach ( $args['choices'] as $key => $item ): ?>
					<?php if ( $key == $value ): ?>
						<option value="<?= $key ?>" selected><?= $item ?></option>
					<?php else: ?>
						<option value="<?= $key ?>"><?= $item ?></option>
					<?php endif ?>
				<?php endforeach ?>
			</select>
		<?php endif ?>

		<?php if ( ! empty( $args['comment'] ) ): ?>
			<p class="description"><?= $args['comment'] ?></p>
		<?php endif ?>

		<?php
	}

	/**
	 * Очистка данных
	 *
	 * @param $options
	 *
	 * @return mixed
	 */
	public function sanitize_callback( $options ) {
		return $options;
	}
}
